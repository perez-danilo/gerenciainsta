-- MySQL dump 10.13  Distrib 5.6.23, for linux-glibc2.5 (x86_64)
--
-- Host: mysql09-farm70.uni5.net    Database: gerenciainsta
-- ------------------------------------------------------
-- Server version	5.6.36-log
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `np_accounts`
--

DROP TABLE IF EXISTS `np_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `instagram_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `proxy` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  `login_required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_2` (`user_id`,`username`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `accounts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_accounts`
--

LOCK TABLES `np_accounts` WRITE;
/*!40000 ALTER TABLE `np_accounts` DISABLE KEYS */;
INSERT INTO `np_accounts` VALUES (3,2,'8322540155','nrvconstrutorasp','def50200b71894ed180531c50129cd5892854e35bbea035d9860850731de3e005d8a299170fc4a5e0f855d48d20bae905d7f54cbcfc49bfc6a8da5615632ee98f63d703a2b6a8b10150a75738179209858e0813e8f70efcf83289c879a6036','','2018-07-30 14:37:53','2018-08-09 23:14:50',0),(5,1,'8322540155','nrvconstrutorasp','def502000a9639f302c3bc0bb405a851d48fc6161be185532b2cb6a607ebd41947f5a479cf763f287736a229a60a5f380365b8a8cd4c9961958dc3b510514e8167ecc7497c34ce280c69ab909d743d060f0ab03c6cc84aceec3a69fc7a035a','','2018-08-02 00:46:19','2018-08-10 12:15:56',0),(7,11,'8395304569','taymisonramos','def502007dbf431bb762b9fb78d66a5afb03342260ce1db8c5ead4433521a15aa86a90fda5d5b4e1d15db97dd3a11574e889a1f0138245aee35d6dfce6fd2f118e5b2279a4c66144b1aaf19a6bee66a7e1b97293ad7c745af71bdbf9','http://181.214.20.37:3128','2018-08-08 16:29:57','2018-08-08 16:44:22',0),(9,15,'8396256731','samsonogen','def50200ba08aa9e0716f2c7f4083a3d8bdaf88c621ebe2794c1c9d113f18cbbefd1c977b724dd5b0d0c089808026689ed71bd0dee258475e560cd194ccd498303c9b8e62206c16cd0fe248e549ace0fe3fb763eec08f0cbb2d3b160b198a5','http://181.214.26.18:3128','2018-08-09 00:20:15','2018-08-09 00:20:15',0),(10,17,'8396486667','diegophhh','def50200a81c87abee07efe022c225e8c7f4b45fec63aaee9dba783916d67aee65a8980b963e52aacd6e53b79180f6b03c42e0ea9e0a51ea407f6697084b8bf839f8f1d665121301de208972ed415001249981c4226434491fb1','http://191.96.11.182:3128','2018-08-09 01:28:07','2018-08-09 11:16:47',0),(11,19,'8398536231','thisisdemo1234','def50200cfa4a62c0d980f011301eae908086f17dc4b467131edd88e2554dcb410e9421b630cd7944492b0e004ce4752b8ee8961945d9b0a1e5ffebd18fdcb8b3fe05d1262b1eefb6ea837ff68330a6dba543bcd3682732c7127bca19693db5b306ba2','http://191.96.137.156:3128','2018-08-09 11:13:49','2018-08-09 11:14:32',0),(13,17,'8399525803','diegophhhh','def5020020bd1384d0bf68de1664e25835e8aa6813c0e31033a6129799b81e5f41ddb491443cabb761ce6e7337e7fcc52621fba8a426fff5e9d1061c49502a53d9ab617988dab04807a18ef926a81863a5f21a265c4a9349c017','http://181.214.6.47:3128','2018-08-09 11:17:55','2018-08-09 11:18:23',0),(14,12,'8393565596','drtomatinhox','def50200e261ad1a1261681b006900139f67c7756cd600f1f0b9f3c2232ada7a2a39226109b9141353798cbb32f0b0fad63c41e81f8c79baa04fb7e01eaf9c544011437fc6a91f373709205d0e3e0c054a6520cd103ffa13e47d06157de660','http://181.214.26.18:3128','2018-08-09 13:07:13','2018-08-09 13:08:04',0),(15,21,'3504975356','solarfilmspeliculasparavidros','def50200b6dd496f1639fc772915b563c128a3cda22f96828b4e8330056212b66529809a7080128138bbe6605306e8cf819ff10c5b170f71dfe6267fd6929ff9841dd60722ae73fb46e24b1689dd904d704824be640e90a871d61e8181545b','http://191.96.11.182:3128','2018-08-09 23:04:47','2018-08-09 23:04:47',1),(16,1,'8403607912','casadecarnecentralsp','def50200f09071cb5c1a0580cacbaa75f1b930288923909c2e6b078e37c2f5c1b5c52fb650f488ea4f28919194a959d9d387800d92247d0c9d4d654b0f69cab9995427af11f2c7dc1ff37010982b519f01c3bec31a085c9a764eba83c73c32','http://191.96.137.156:3128','2018-08-09 23:38:56','2018-08-10 01:40:19',0),(17,1,'8403138748','maninimarmorariasp','def502008dbbef4c0c381869233f2d95bc3f0614839ed747ea15242ed9c469d9edbcbf309953353c538016d275a8d8d04e1f6310e023ccd172c1c811fd1019175ac3233c6c1bdbe2e2f1745ab59ff8323c897e425fd6a42a7c650f39ceb6a9','http://181.214.20.37:3128','2018-08-10 00:20:46','2018-08-15 21:09:58',0);
/*!40000 ALTER TABLE `np_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_comment_log`
--

DROP TABLE IF EXISTS `np_auto_comment_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_comment_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `commented_media_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  KEY `commented_media_code` (`commented_media_code`),
  CONSTRAINT `ibfk_5b57c19beffcc` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c19bf0019` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_comment_log`
--

LOCK TABLES `np_auto_comment_log` WRITE;
/*!40000 ALTER TABLE `np_auto_comment_log` DISABLE KEYS */;
INSERT INTO `np_auto_comment_log` VALUES (1,1,5,'error','','{\"trigger\":{\"type\":\"timeline_feed\"},\"error\":{\"msg\":\"Couldn\'t find any new media to comment in the timeline feed\"}}','2018-08-07 23:38:53');
/*!40000 ALTER TABLE `np_auto_comment_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_comment_schedule`
--

DROP TABLE IF EXISTS `np_auto_comment_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_comment_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `target` text COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `timeline_feed` text COLLATE utf8_unicode_ci NOT NULL,
  `speed` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `daily_pause` tinyint(1) NOT NULL,
  `daily_pause_from` time NOT NULL,
  `daily_pause_to` time NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `schedule_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `last_action_date` datetime NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `ibfk_5b57c19beff2d` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c19beff7e` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_comment_schedule`
--

LOCK TABLES `np_auto_comment_schedule` WRITE;
/*!40000 ALTER TABLE `np_auto_comment_schedule` DISABLE KEYS */;
INSERT INTO `np_auto_comment_schedule` VALUES (2,1,5,'[{\"type\":\"location\",\"id\":\"108259652527599\",\"value\":\"Araraquara\"},{\"type\":\"people\",\"id\":\"4387359382\",\"value\":\"bruno.gcosta\"},{\"type\":\"people\",\"id\":\"197234878\",\"value\":\"brunoot23\"},{\"type\":\"people\",\"id\":\"20053826\",\"value\":\"brunomars\"},{\"type\":\"people\",\"id\":\"5383478\",\"value\":\"brumarquezine\"},{\"type\":\"people\",\"id\":\"7922122456\",\"value\":\"bruno.souzadasilva.9\"},{\"type\":\"people\",\"id\":\"5572890906\",\"value\":\"bruurvc\"},{\"type\":\"people\",\"id\":\"21025821\",\"value\":\"brunogagliasso\"},{\"type\":\"people\",\"id\":\"25160135\",\"value\":\"brunogissoni\"},{\"type\":\"people\",\"id\":\"230011190\",\"value\":\"bru.r.lopes\"},{\"type\":\"people\",\"id\":\"7055721534\",\"value\":\"brunaferrazoficial77\"},{\"type\":\"people\",\"id\":\"182651180\",\"value\":\"brunoberti\"},{\"type\":\"people\",\"id\":\"7384127936\",\"value\":\"joaopedrobrunetti\"},{\"type\":\"people\",\"id\":\"4531343178\",\"value\":\"brunaojhran\"},{\"type\":\"people\",\"id\":\"210051441\",\"value\":\"brunahamu\"},{\"type\":\"people\",\"id\":\"225186814\",\"value\":\"brunagriphaoo\"},{\"type\":\"people\",\"id\":\"678761378\",\"value\":\"patrociniophotostudio\"},{\"type\":\"people\",\"id\":\"268029127\",\"value\":\"bruno41batata\"},{\"type\":\"people\",\"id\":\"1474850876\",\"value\":\"bruno.oliver91\"},{\"type\":\"people\",\"id\":\"34992485\",\"value\":\"brunosutter\"},{\"type\":\"people\",\"id\":\"2008604156\",\"value\":\"mirim_bruna\"},{\"type\":\"people\",\"id\":\"7075813871\",\"value\":\"bruno_ricardo_lopes\"},{\"type\":\"people\",\"id\":\"4361890262\",\"value\":\"brunoamar50hotmail.com7535\"}]','[\"{{username}}\\nConhe\\u00e7a a NRV CONSTRUTORA. \\nTemos casas com terrenos a partir de R$125.000,00\\n\\nwww.nrvconstrutora.com.br\"]','{\"enabled\":true,\"schedule_date\":\"2018-08-07 23:51:51\"}','auto',0,'00:00:00','00:00:00',1,'2018-08-08 00:14:33','2030-12-12 23:59:59','2018-08-07 23:38:52','{}'),(3,1,17,'[{\"type\":\"hashtag\",\"id\":\"araraquara\",\"value\":\"araraquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaracity\",\"value\":\"araraquaracity\"},{\"type\":\"hashtag\",\"id\":\"mtbararaquara\",\"value\":\"mtbararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquarasp\",\"value\":\"araraquarasp\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umt\",\"value\":\"araraquara\\u00e9umt\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umtes\\u00e3o\",\"value\":\"araraquara\\u00e9umtes\\u00e3o\"},{\"type\":\"hashtag\",\"id\":\"araraquararock\",\"value\":\"araraquararock\"},{\"type\":\"hashtag\",\"id\":\"araraquarafood\",\"value\":\"araraquarafood\"},{\"type\":\"hashtag\",\"id\":\"araraquaratattoo\",\"value\":\"araraquaratattoo\"},{\"type\":\"hashtag\",\"id\":\"araraquara200anos\",\"value\":\"araraquara200anos\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umtesao\",\"value\":\"araraquara\\u00e9umtesao\"},{\"type\":\"hashtag\",\"id\":\"araraquarafitness\",\"value\":\"araraquarafitness\"},{\"type\":\"hashtag\",\"id\":\"araraquaraeumtesao\",\"value\":\"araraquaraeumtesao\"},{\"type\":\"hashtag\",\"id\":\"lafamiliatattooararaquara\",\"value\":\"lafamiliatattooararaquara\"},{\"type\":\"hashtag\",\"id\":\"unespararaquara\",\"value\":\"unespararaquara\"},{\"type\":\"hashtag\",\"id\":\"agitoararaquara\",\"value\":\"agitoararaquara\"},{\"type\":\"hashtag\",\"id\":\"crossfitararaquara\",\"value\":\"crossfitararaquara\"},{\"type\":\"hashtag\",\"id\":\"sescararaquara\",\"value\":\"sescararaquara\"},{\"type\":\"hashtag\",\"id\":\"euindicochilenotattooararaquara\",\"value\":\"euindicochilenotattooararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaramoradadosol\",\"value\":\"araraquaramoradadosol\"},{\"type\":\"hashtag\",\"id\":\"araraquaracountryfest\",\"value\":\"araraquaracountryfest\"},{\"type\":\"hashtag\",\"id\":\"araraquarafeet\",\"value\":\"araraquarafeet\"},{\"type\":\"hashtag\",\"id\":\"vempral\\u00edquidoararaquara\",\"value\":\"vempral\\u00edquidoararaquara\"},{\"type\":\"hashtag\",\"id\":\"mangaverdeararaquara\",\"value\":\"mangaverdeararaquara\"},{\"type\":\"hashtag\",\"id\":\"naoparaararaquara\",\"value\":\"naoparaararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaraemcena\",\"value\":\"araraquaraemcena\"},{\"type\":\"hashtag\",\"id\":\"araraquaraeregi\\u00e3o\",\"value\":\"araraquaraeregi\\u00e3o\"},{\"type\":\"hashtag\",\"id\":\"yogaararaquara\",\"value\":\"yogaararaquara\"},{\"type\":\"hashtag\",\"id\":\"interararaquara\",\"value\":\"interararaquara\"},{\"type\":\"hashtag\",\"id\":\"clubemelissaararaquara\",\"value\":\"clubemelissaararaquara\"},{\"type\":\"location\",\"id\":\"108259652527599\",\"value\":\"Araraquara\"},{\"type\":\"location\",\"id\":\"821338214672792\",\"value\":\"Araraquara Morada do Sol\"},{\"type\":\"location\",\"id\":\"477547029035479\",\"value\":\"Shopping Jaragu\\u00e1 Concei\\u00e7\\u00e3o\"},{\"type\":\"location\",\"id\":\"109101979112042\",\"value\":\"Centro Tur\\u00e9n, Portuguesa, Venezuela\"},{\"type\":\"location\",\"id\":\"199417360164391\",\"value\":\"Sesc Araraquara\"},{\"type\":\"location\",\"id\":\"203730886337123\",\"value\":\"Universidade de Araraquara\"},{\"type\":\"location\",\"id\":\"303165766365752\",\"value\":\"Vila Xavier, Araraquara\"},{\"type\":\"location\",\"id\":\"159481290914152\",\"value\":\"Clube N\\u00e1utico Araraquara\"},{\"type\":\"location\",\"id\":\"257214134326689\",\"value\":\"SESI Araraquara\"},{\"type\":\"location\",\"id\":\"1601057950223054\",\"value\":\"Espa\\u00e7o Caf\\u00e9 Araraquara\"},{\"type\":\"location\",\"id\":\"678535868886030\",\"value\":\"Hotel Dan Inn Araraquara\"},{\"type\":\"location\",\"id\":\"1425692921081791\",\"value\":\"Rock & Ribs Lounge Araraquara\"},{\"type\":\"location\",\"id\":\"425894714101094\",\"value\":\"Universidade Paulista Unip Araraquara\"},{\"type\":\"location\",\"id\":\"209257532453661\",\"value\":\"Heineken Brasil Araraquara\"},{\"type\":\"location\",\"id\":\"516865911660204\",\"value\":\"Sakana Araraquara\"},{\"type\":\"location\",\"id\":\"281514025220988\",\"value\":\"R\\u00e1dio Cultura Araraquara\"},{\"type\":\"location\",\"id\":\"251854168197653\",\"value\":\"Bar do Portugu\\u00eas - Araraquara\"},{\"type\":\"location\",\"id\":\"129796860433517\",\"value\":\"Padaria P\\u00e3o da Terra Araraquara\"},{\"type\":\"location\",\"id\":\"279699048751883\",\"value\":\"Senac Araraquara\"},{\"type\":\"location\",\"id\":\"188009621283507\",\"value\":\"R\\u00e1dio Morada Araraquara\"},{\"type\":\"people\",\"id\":\"3537841540\",\"value\":\"coc.araraquara\"},{\"type\":\"people\",\"id\":\"828346497\",\"value\":\"shoppingjaraguaararaquara\"},{\"type\":\"people\",\"id\":\"1211629862\",\"value\":\"equilibrio_araraquara\"},{\"type\":\"people\",\"id\":\"1811047067\",\"value\":\"clubemelissaararaquara\"},{\"type\":\"people\",\"id\":\"3285321255\",\"value\":\"ointeroficial\"},{\"type\":\"people\",\"id\":\"7336970604\",\"value\":\"bardasextaararaquara\"},{\"type\":\"people\",\"id\":\"12347490\",\"value\":\"araraquara\"},{\"type\":\"people\",\"id\":\"7709091836\",\"value\":\"maxgym_araraquara\"},{\"type\":\"people\",\"id\":\"5882812157\",\"value\":\"emagresee.araraquara\"},{\"type\":\"people\",\"id\":\"3205088729\",\"value\":\"espacocafe.araraquara\"},{\"type\":\"people\",\"id\":\"7291582533\",\"value\":\"brexodoararaquara\"},{\"type\":\"people\",\"id\":\"7584920120\",\"value\":\"lojamfararaquara\"},{\"type\":\"people\",\"id\":\"5506979418\",\"value\":\"brooksararaquara\"},{\"type\":\"people\",\"id\":\"1984610528\",\"value\":\"liquido_araraquara\"},{\"type\":\"people\",\"id\":\"6248577306\",\"value\":\"protocoloar\"},{\"type\":\"people\",\"id\":\"6679481031\",\"value\":\"araraquaraemcena\"},{\"type\":\"people\",\"id\":\"8388203645\",\"value\":\"rotaryclubararaquararacarmo\"},{\"type\":\"people\",\"id\":\"5498281494\",\"value\":\"moranaararaquara\"},{\"type\":\"people\",\"id\":\"7286626111\",\"value\":\"almanaque.araraquara\"},{\"type\":\"people\",\"id\":\"5850197759\",\"value\":\"sncararaquara\"},{\"type\":\"people\",\"id\":\"4455506709\",\"value\":\"boladeneveararaquara\"},{\"type\":\"people\",\"id\":\"218406369\",\"value\":\"helenareisl\"},{\"type\":\"people\",\"id\":\"3278578237\",\"value\":\"sanmartinararaquaracentro\"},{\"type\":\"people\",\"id\":\"2343067500\",\"value\":\"lpm_araraquara\"},{\"type\":\"people\",\"id\":\"452488917\",\"value\":\"lafamiliatattooararaquara\"}]','[\"Conhe\\u00e7a a Marmoria Manini.\\nhttp:\\/\\/www.marmorariamanini.com.br\\/\"]','{\"enabled\":false}','auto',0,'00:00:00','00:00:00',1,'2018-08-10 00:33:06','2030-12-12 23:59:59','2018-08-10 00:32:06','{}'),(4,1,16,'[]','[\"{{username}}\\nVenha visitar nossa loja. Estamos com promo\\u00e7\\u00f5es incr\\u00edveis.\\nAceitamos encomendas: Tel.(16) 3301-4955\"]','{}','1',0,'00:00:00','00:00:00',0,'2018-08-10 00:56:15','2018-08-10 00:56:15','2018-08-10 00:56:15','{}');
/*!40000 ALTER TABLE `np_auto_comment_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_follow_log`
--

DROP TABLE IF EXISTS `np_auto_follow_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_follow_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `followed_user_pk` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  KEY `followed_user_pk` (`followed_user_pk`),
  CONSTRAINT `ibfk_5b57c1b02570f` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c1b025762` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_follow_log`
--

LOCK TABLES `np_auto_follow_log` WRITE;
/*!40000 ALTER TABLE `np_auto_follow_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `np_auto_follow_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_follow_schedule`
--

DROP TABLE IF EXISTS `np_auto_follow_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_follow_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `target` text COLLATE utf8_unicode_ci NOT NULL,
  `speed` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `daily_pause` tinyint(1) NOT NULL,
  `daily_pause_from` time NOT NULL,
  `daily_pause_to` time NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `schedule_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `last_action_date` datetime NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `ibfk_5b57c1b02566b` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c1b0256c0` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_follow_schedule`
--

LOCK TABLES `np_auto_follow_schedule` WRITE;
/*!40000 ALTER TABLE `np_auto_follow_schedule` DISABLE KEYS */;
INSERT INTO `np_auto_follow_schedule` VALUES (1,2,3,'[{\"type\":\"people\",\"id\":\"1940282644\",\"value\":\"luizfernandoc9\"},{\"type\":\"people\",\"id\":\"219397803\",\"value\":\"mluizavilla\"},{\"type\":\"people\",\"id\":\"1817596355\",\"value\":\"gersonluizrorato\"},{\"type\":\"people\",\"id\":\"263736324\",\"value\":\"luiz\"}]','very_slow',0,'00:00:00','00:00:00',1,'2018-08-08 00:38:53','2030-12-12 23:59:59','2018-08-07 23:38:53','{}'),(2,1,5,'[{\"type\":\"people\",\"id\":\"1609840933\",\"value\":\"alinepegrucci\"},{\"type\":\"people\",\"id\":\"1424277533\",\"value\":\"lima.trabalho\"},{\"type\":\"people\",\"id\":\"259925762\",\"value\":\"aliaabhatt\"},{\"type\":\"people\",\"id\":\"6831891479\",\"value\":\"officialallteaallshade\"},{\"type\":\"people\",\"id\":\"1300790487\",\"value\":\"alinecardoso.gomes\"},{\"type\":\"people\",\"id\":\"1706752278\",\"value\":\"cartoon_best_moments\"},{\"type\":\"people\",\"id\":\"427618038\",\"value\":\"alinekayza\"},{\"type\":\"people\",\"id\":\"252016549\",\"value\":\"alexgalindo.sc\"},{\"type\":\"people\",\"id\":\"4816395667\",\"value\":\"altairyan\"},{\"type\":\"people\",\"id\":\"12411530\",\"value\":\"allison.parker22\"},{\"type\":\"people\",\"id\":\"28656806\",\"value\":\"alexisren\"},{\"type\":\"people\",\"id\":\"7384563361\",\"value\":\"alessandraespacofeminino\"},{\"type\":\"people\",\"id\":\"6268600919\",\"value\":\"aliomard\"},{\"type\":\"people\",\"id\":\"862179041\",\"value\":\"aline_peccinin\"},{\"type\":\"people\",\"id\":\"8359273069\",\"value\":\"alexandrebsilva11\"},{\"type\":\"people\",\"id\":\"3146754284\",\"value\":\"alessando_lopes_correa\"},{\"type\":\"people\",\"id\":\"44352669\",\"value\":\"alessandraambrosio\"},{\"type\":\"people\",\"id\":\"733941117\",\"value\":\"alexrafaelgouvea\"},{\"type\":\"people\",\"id\":\"1929875881\",\"value\":\"masih.alinejad\"},{\"type\":\"people\",\"id\":\"575361323\",\"value\":\"aliffsyukriterlajaklaris\"},{\"type\":\"people\",\"id\":\"3258692858\",\"value\":\"alextamasco\"},{\"type\":\"location\",\"id\":\"108259652527599\",\"value\":\"Araraquara\"},{\"type\":\"location\",\"id\":\"821338214672792\",\"value\":\"Araraquara Morada do Sol\"},{\"type\":\"location\",\"id\":\"109101979112042\",\"value\":\"Centro Tur\\u00e9n, Portuguesa, Venezuela\"},{\"type\":\"location\",\"id\":\"199417360164391\",\"value\":\"Sesc Araraquara\"},{\"type\":\"location\",\"id\":\"159481290914152\",\"value\":\"Clube N\\u00e1utico Araraquara\"},{\"type\":\"location\",\"id\":\"907801882670254\",\"value\":\"Matriz Araraquara\"},{\"type\":\"location\",\"id\":\"203730886337123\",\"value\":\"Universidade de Araraquara\"},{\"type\":\"location\",\"id\":\"477547029035479\",\"value\":\"Shopping Jaragu\\u00e1 Concei\\u00e7\\u00e3o\"},{\"type\":\"location\",\"id\":\"393334140868658\",\"value\":\"Progresso de Araraquara Col\\u00e9gio\"},{\"type\":\"location\",\"id\":\"303165766365752\",\"value\":\"Vila Xavier, Araraquara\"},{\"type\":\"location\",\"id\":\"609021185837172\",\"value\":\"Boteco P\\u00e9 na Cova\"},{\"type\":\"location\",\"id\":\"189889044387598\",\"value\":\"Almanaque Bar & Club\"},{\"type\":\"location\",\"id\":\"209925759377949\",\"value\":\"Uniara - Universidade de Araraquara\"},{\"type\":\"location\",\"id\":\"226517567448015\",\"value\":\"Shopping Lupo Araraquara\"},{\"type\":\"location\",\"id\":\"137424926420085\",\"value\":\"Cacha\\u00e7aria \\u00c1gua Doce Araraquara\"},{\"type\":\"location\",\"id\":\"220716828310816\",\"value\":\"Maternidade Gota de Leite de Araraquara-FunGota\"},{\"type\":\"location\",\"id\":\"257214134326689\",\"value\":\"SESI Araraquara\"},{\"type\":\"location\",\"id\":\"1528834504026492\",\"value\":\"AABB - Associa\\u00e7\\u00e3o Atl\\u00e9tica Banco do Brasil Araraquara-SP\"},{\"type\":\"location\",\"id\":\"928232883938786\",\"value\":\"C\\u00e2mara Municipal de Araraquara\"},{\"type\":\"location\",\"id\":\"177572189411468\",\"value\":\"Japa A\\u00e7a\\u00ed - Araraquara\"},{\"type\":\"location\",\"id\":\"425894714101094\",\"value\":\"Universidade Paulista Unip Araraquara\"},{\"type\":\"location\",\"id\":\"516865911660204\",\"value\":\"Sakana Araraquara\"},{\"type\":\"location\",\"id\":\"225704610954125\",\"value\":\"FCLAR - Faculdade de Ci\\u00eancias e Letras da Unesp Araraquara\"},{\"type\":\"location\",\"id\":\"266490783394385\",\"value\":\"Clube Araraquarense\"},{\"type\":\"people\",\"id\":\"8056091042\",\"value\":\"araraquara_rock\"},{\"type\":\"people\",\"id\":\"1984610528\",\"value\":\"liquido_araraquara\"},{\"type\":\"people\",\"id\":\"797137842\",\"value\":\"american.burger.araraquara\"},{\"type\":\"people\",\"id\":\"5846866925\",\"value\":\"formatcomp_araraquara\"},{\"type\":\"people\",\"id\":\"3118322981\",\"value\":\"mmartanararaquara\"},{\"type\":\"people\",\"id\":\"12347490\",\"value\":\"araraquara\"},{\"type\":\"people\",\"id\":\"3205088729\",\"value\":\"espacocafe.araraquara\"},{\"type\":\"people\",\"id\":\"4776234547\",\"value\":\"cachacariaararaquara\"},{\"type\":\"people\",\"id\":\"341590323\",\"value\":\"outletlingerie_araraquara\"},{\"type\":\"people\",\"id\":\"5571521970\",\"value\":\"afararaquara\"},{\"type\":\"people\",\"id\":\"1097512172\",\"value\":\"requinte_eventosararaquara\"},{\"type\":\"people\",\"id\":\"350194080\",\"value\":\"agito.araraquara\"},{\"type\":\"people\",\"id\":\"452488917\",\"value\":\"lafamiliatattooararaquara\"},{\"type\":\"people\",\"id\":\"3285321255\",\"value\":\"ointeroficial\"},{\"type\":\"people\",\"id\":\"6160136857\",\"value\":\"arboararaquara\"},{\"type\":\"people\",\"id\":\"8202918323\",\"value\":\"teviemararaquara\"},{\"type\":\"people\",\"id\":\"6679481031\",\"value\":\"araraquaraemcena\"},{\"type\":\"people\",\"id\":\"2046939198\",\"value\":\"studio_perola_clinica\"}]','auto',0,'00:00:00','00:00:00',1,'2018-08-10 01:43:58','2030-12-12 23:59:59','2018-08-07 14:24:19','{}'),(3,17,10,'[{\"type\":\"hashtag\",\"id\":\"java\",\"value\":\"java\"}]','medium',0,'00:00:00','00:00:00',1,'2018-08-09 01:45:59','2030-12-12 23:59:59','2018-08-09 01:43:58','{}'),(4,1,16,'[{\"type\":\"hashtag\",\"id\":\"araraquara\",\"value\":\"araraquara\"},{\"type\":\"location\",\"id\":\"108259652527599\",\"value\":\"Araraquara\"},{\"type\":\"location\",\"id\":\"199417360164391\",\"value\":\"Sesc Araraquara\"},{\"type\":\"location\",\"id\":\"477547029035479\",\"value\":\"Shopping Jaragu\\u00e1 Concei\\u00e7\\u00e3o\"},{\"type\":\"location\",\"id\":\"821338214672792\",\"value\":\"Araraquara Morada do Sol\"},{\"type\":\"location\",\"id\":\"159481290914152\",\"value\":\"Clube N\\u00e1utico Araraquara\"},{\"type\":\"location\",\"id\":\"257214134326689\",\"value\":\"SESI Araraquara\"},{\"type\":\"location\",\"id\":\"1425692921081791\",\"value\":\"Rock & Ribs Lounge Araraquara\"},{\"type\":\"location\",\"id\":\"1601057950223054\",\"value\":\"Espa\\u00e7o Caf\\u00e9 Araraquara\"},{\"type\":\"location\",\"id\":\"303165766365752\",\"value\":\"Vila Xavier, Araraquara\"},{\"type\":\"people\",\"id\":\"828346497\",\"value\":\"shoppingjaraguaararaquara\"},{\"type\":\"people\",\"id\":\"5503926147\",\"value\":\"ficadicaararaquara\"},{\"type\":\"people\",\"id\":\"2305232200\",\"value\":\"objetivo.araraquara\"},{\"type\":\"people\",\"id\":\"8355554687\",\"value\":\"speed_burger_araraquara\"},{\"type\":\"people\",\"id\":\"1211629862\",\"value\":\"equilibrio_araraquara\"},{\"type\":\"people\",\"id\":\"522763222\",\"value\":\"lbfararaquara\"},{\"type\":\"people\",\"id\":\"3537841540\",\"value\":\"coc.araraquara\"},{\"type\":\"people\",\"id\":\"1984610528\",\"value\":\"liquido_araraquara\"},{\"type\":\"people\",\"id\":\"5882812157\",\"value\":\"emagresee.araraquara\"},{\"type\":\"people\",\"id\":\"1811047067\",\"value\":\"clubemelissaararaquara\"},{\"type\":\"people\",\"id\":\"341590323\",\"value\":\"outletlingerie_araraquara\"},{\"type\":\"people\",\"id\":\"3205088729\",\"value\":\"espacocafe.araraquara\"},{\"type\":\"people\",\"id\":\"5506979418\",\"value\":\"brooksararaquara\"},{\"type\":\"people\",\"id\":\"3990806129\",\"value\":\"kidstok.araraquara\"},{\"type\":\"people\",\"id\":\"5788737703\",\"value\":\"araraquarachinainbox\"},{\"type\":\"people\",\"id\":\"6236297253\",\"value\":\"araraquara_news\"},{\"type\":\"people\",\"id\":\"5850197759\",\"value\":\"sncararaquara\"},{\"type\":\"people\",\"id\":\"3118322981\",\"value\":\"mmartanararaquara\"},{\"type\":\"people\",\"id\":\"6248577306\",\"value\":\"protocoloar\"},{\"type\":\"people\",\"id\":\"6679481031\",\"value\":\"araraquaraemcena\"},{\"type\":\"people\",\"id\":\"5571521970\",\"value\":\"afararaquara\"},{\"type\":\"people\",\"id\":\"6911180819\",\"value\":\"marciacostureiraararaquara\"}]','very_fast',0,'00:00:00','00:00:00',1,'2018-08-09 23:58:34','2030-12-12 23:59:59','2018-08-09 23:56:29','{}'),(5,1,17,'[{\"type\":\"hashtag\",\"id\":\"araraquara\",\"value\":\"araraquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaracity\",\"value\":\"araraquaracity\"},{\"type\":\"hashtag\",\"id\":\"araraquarasp\",\"value\":\"araraquarasp\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umt\",\"value\":\"araraquara\\u00e9umt\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umtes\\u00e3o\",\"value\":\"araraquara\\u00e9umtes\\u00e3o\"},{\"type\":\"hashtag\",\"id\":\"araraquararock\",\"value\":\"araraquararock\"},{\"type\":\"hashtag\",\"id\":\"araraquarafood\",\"value\":\"araraquarafood\"},{\"type\":\"hashtag\",\"id\":\"araraquaratattoo\",\"value\":\"araraquaratattoo\"},{\"type\":\"hashtag\",\"id\":\"araraquara200anos\",\"value\":\"araraquara200anos\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umtesao\",\"value\":\"araraquara\\u00e9umtesao\"},{\"type\":\"hashtag\",\"id\":\"araraquarafitness\",\"value\":\"araraquarafitness\"},{\"type\":\"hashtag\",\"id\":\"araraquaraeumtesao\",\"value\":\"araraquaraeumtesao\"},{\"type\":\"hashtag\",\"id\":\"lafamiliatattooararaquara\",\"value\":\"lafamiliatattooararaquara\"},{\"type\":\"hashtag\",\"id\":\"unespararaquara\",\"value\":\"unespararaquara\"},{\"type\":\"hashtag\",\"id\":\"agitoararaquara\",\"value\":\"agitoararaquara\"},{\"type\":\"hashtag\",\"id\":\"crossfitararaquara\",\"value\":\"crossfitararaquara\"},{\"type\":\"hashtag\",\"id\":\"sescararaquara\",\"value\":\"sescararaquara\"},{\"type\":\"hashtag\",\"id\":\"euindicochilenotattooararaquara\",\"value\":\"euindicochilenotattooararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaramoradadosol\",\"value\":\"araraquaramoradadosol\"},{\"type\":\"hashtag\",\"id\":\"araraquaracountryfest\",\"value\":\"araraquaracountryfest\"},{\"type\":\"hashtag\",\"id\":\"araraquarafeet\",\"value\":\"araraquarafeet\"},{\"type\":\"hashtag\",\"id\":\"vempral\\u00edquidoararaquara\",\"value\":\"vempral\\u00edquidoararaquara\"},{\"type\":\"hashtag\",\"id\":\"mangaverdeararaquara\",\"value\":\"mangaverdeararaquara\"},{\"type\":\"hashtag\",\"id\":\"naoparaararaquara\",\"value\":\"naoparaararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaraemcena\",\"value\":\"araraquaraemcena\"},{\"type\":\"hashtag\",\"id\":\"araraquaraeregi\\u00e3o\",\"value\":\"araraquaraeregi\\u00e3o\"},{\"type\":\"hashtag\",\"id\":\"yogaararaquara\",\"value\":\"yogaararaquara\"},{\"type\":\"hashtag\",\"id\":\"interararaquara\",\"value\":\"interararaquara\"},{\"type\":\"hashtag\",\"id\":\"clubemelissaararaquara\",\"value\":\"clubemelissaararaquara\"},{\"type\":\"hashtag\",\"id\":\"mtbararaquara\",\"value\":\"mtbararaquara\"},{\"type\":\"location\",\"id\":\"821338214672792\",\"value\":\"Araraquara Morada do Sol\"},{\"type\":\"location\",\"id\":\"477547029035479\",\"value\":\"Shopping Jaragu\\u00e1 Concei\\u00e7\\u00e3o\"},{\"type\":\"location\",\"id\":\"109101979112042\",\"value\":\"Centro Tur\\u00e9n, Portuguesa, Venezuela\"},{\"type\":\"location\",\"id\":\"199417360164391\",\"value\":\"Sesc Araraquara\"},{\"type\":\"location\",\"id\":\"203730886337123\",\"value\":\"Universidade de Araraquara\"},{\"type\":\"location\",\"id\":\"303165766365752\",\"value\":\"Vila Xavier, Araraquara\"},{\"type\":\"location\",\"id\":\"159481290914152\",\"value\":\"Clube N\\u00e1utico Araraquara\"},{\"type\":\"location\",\"id\":\"257214134326689\",\"value\":\"SESI Araraquara\"},{\"type\":\"people\",\"id\":\"3537841540\",\"value\":\"coc.araraquara\"},{\"type\":\"people\",\"id\":\"1211629862\",\"value\":\"equilibrio_araraquara\"},{\"type\":\"people\",\"id\":\"1811047067\",\"value\":\"clubemelissaararaquara\"},{\"type\":\"people\",\"id\":\"3285321255\",\"value\":\"ointeroficial\"},{\"type\":\"people\",\"id\":\"7336970604\",\"value\":\"bardasextaararaquara\"},{\"type\":\"people\",\"id\":\"12347490\",\"value\":\"araraquara\"},{\"type\":\"people\",\"id\":\"7709091836\",\"value\":\"maxgym_araraquara\"},{\"type\":\"people\",\"id\":\"5882812157\",\"value\":\"emagresee.araraquara\"},{\"type\":\"people\",\"id\":\"3205088729\",\"value\":\"espacocafe.araraquara\"},{\"type\":\"people\",\"id\":\"7291582533\",\"value\":\"brexodoararaquara\"},{\"type\":\"people\",\"id\":\"7584920120\",\"value\":\"lojamfararaquara\"}]','auto',0,'00:00:00','00:00:00',1,'2018-08-10 00:35:47','2030-12-12 23:59:59','2018-08-10 00:34:47','{}');
/*!40000 ALTER TABLE `np_auto_follow_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_like_log`
--

DROP TABLE IF EXISTS `np_auto_like_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_like_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `liked_media_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  KEY `liked_media_code` (`liked_media_code`),
  CONSTRAINT `ibfk_5b57c1bdc55bd` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c1bdc560a` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_like_log`
--

LOCK TABLES `np_auto_like_log` WRITE;
/*!40000 ALTER TABLE `np_auto_like_log` DISABLE KEYS */;
INSERT INTO `np_auto_like_log` VALUES (1,2,3,'success','BmEUC-lnq-v','{\"trigger\":{\"type\":\"people\",\"id\":\"287914102\",\"value\":\"luisasonza\"},\"liked\":{\"media_id\":\"1838682713446330287_287914102\",\"media_code\":\"BmEUC-lnq-v\",\"media_type\":1,\"media_thumb\":\"https:\\/\\/scontent-gru2-1.cdninstagram.com\\/vp\\/b51f77e04418fb41c1f30966683fcbc8\\/5BEF0E86\\/t51.2885-15\\/e35\\/37666521_289306971833616_5330315462448250880_n.jpg?se=8&ig_cache_key=MTgzODY4MjcxMzQ0NjMzMDI4Nw%3D%3D.2\",\"user\":{\"pk\":\"287914102\",\"username\":\"luisasonza\",\"full_name\":\"Lu\\u00edsa Gerloff Sonza\"}}}','2018-08-07 23:38:55'),(2,1,5,'success','Bl9f_o2Fj4_','{\"trigger\":{\"type\":\"timeline_feed\"},\"liked\":{\"media_id\":\"1836764935663009343_4841652116\",\"media_code\":\"Bl9f_o2Fj4_\",\"media_type\":2,\"media_thumb\":\"https:\\/\\/scontent-gru2-1.cdninstagram.com\\/vp\\/d8278343e10a4ddd73d2157ad09ee0ee\\/5B6C6AC8\\/t51.2885-15\\/e35\\/37855072_247244842774138_8020459415024959488_n.jpg?ig_cache_key=MTgzNjc2NDkzNTY2MzAwOTM0Mw%3D%3D.2\",\"user\":{\"pk\":\"4841652116\",\"username\":\"marciawebsite\",\"full_name\":\"Marcia Web Divulga Mais\"}}}','2018-08-07 23:38:56');
/*!40000 ALTER TABLE `np_auto_like_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_like_schedule`
--

DROP TABLE IF EXISTS `np_auto_like_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_like_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `target` text COLLATE utf8_unicode_ci NOT NULL,
  `timeline_feed` text COLLATE utf8_unicode_ci NOT NULL,
  `speed` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `daily_pause` tinyint(1) NOT NULL,
  `daily_pause_from` time NOT NULL,
  `daily_pause_to` time NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `schedule_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `last_action_date` datetime NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `ibfk_5b57c1bdc5517` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c1bdc556d` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_like_schedule`
--

LOCK TABLES `np_auto_like_schedule` WRITE;
/*!40000 ALTER TABLE `np_auto_like_schedule` DISABLE KEYS */;
INSERT INTO `np_auto_like_schedule` VALUES (2,2,3,'[{\"type\":\"people\",\"id\":\"287914102\",\"value\":\"luisasonza\"},{\"type\":\"people\",\"id\":\"6012115361\",\"value\":\"luizcarloscaromano\"},{\"type\":\"people\",\"id\":\"1465077265\",\"value\":\"andreluisarandaa\"},{\"type\":\"people\",\"id\":\"5542496049\",\"value\":\"luiz_paulo_molina\"}]','{\"enabled\":false}','auto',0,'00:00:00','00:00:00',1,'2018-08-08 01:13:37','2030-12-12 23:59:59','2018-08-07 23:38:54','{}'),(3,1,5,'[]','{\"enabled\":true,\"schedule_date\":\"2018-08-08 01:38:24\"}','auto',0,'00:00:00','00:00:00',1,'2018-08-08 01:37:25','2030-12-12 23:59:59','2018-08-07 23:38:55','{}'),(4,1,16,'[{\"type\":\"hashtag\",\"id\":\"araraquara\",\"value\":\"araraquara\"},{\"type\":\"location\",\"id\":\"821338214672792\",\"value\":\"Araraquara Morada do Sol\"},{\"type\":\"location\",\"id\":\"477547029035479\",\"value\":\"Shopping Jaragu\\u00e1 Concei\\u00e7\\u00e3o\"},{\"type\":\"location\",\"id\":\"199417360164391\",\"value\":\"Sesc Araraquara\"},{\"type\":\"location\",\"id\":\"203730886337123\",\"value\":\"Universidade de Araraquara\"},{\"type\":\"location\",\"id\":\"303165766365752\",\"value\":\"Vila Xavier, Araraquara\"},{\"type\":\"location\",\"id\":\"159481290914152\",\"value\":\"Clube N\\u00e1utico Araraquara\"},{\"type\":\"location\",\"id\":\"109101979112042\",\"value\":\"Centro Tur\\u00e9n, Portuguesa, Venezuela\"},{\"type\":\"location\",\"id\":\"257214134326689\",\"value\":\"SESI Araraquara\"},{\"type\":\"location\",\"id\":\"1601057950223054\",\"value\":\"Espa\\u00e7o Caf\\u00e9 Araraquara\"},{\"type\":\"location\",\"id\":\"1425692921081791\",\"value\":\"Rock & Ribs Lounge Araraquara\"},{\"type\":\"location\",\"id\":\"678535868886030\",\"value\":\"Hotel Dan Inn Araraquara\"},{\"type\":\"location\",\"id\":\"209257532453661\",\"value\":\"Heineken Brasil Araraquara\"},{\"type\":\"location\",\"id\":\"425894714101094\",\"value\":\"Universidade Paulista Unip Araraquara\"},{\"type\":\"location\",\"id\":\"516865911660204\",\"value\":\"Sakana Araraquara\"},{\"type\":\"location\",\"id\":\"281514025220988\",\"value\":\"R\\u00e1dio Cultura Araraquara\"},{\"type\":\"location\",\"id\":\"251854168197653\",\"value\":\"Bar do Portugu\\u00eas - Araraquara\"},{\"type\":\"location\",\"id\":\"129796860433517\",\"value\":\"Padaria P\\u00e3o da Terra Araraquara\"},{\"type\":\"location\",\"id\":\"339115442792829\",\"value\":\"Senai Araraquara\"},{\"type\":\"location\",\"id\":\"209925759377949\",\"value\":\"Uniara - Universidade de Araraquara\"},{\"type\":\"location\",\"id\":\"188009621283507\",\"value\":\"R\\u00e1dio Morada Araraquara\"},{\"type\":\"location\",\"id\":\"137424926420085\",\"value\":\"Cacha\\u00e7aria \\u00c1gua Doce Araraquara\"},{\"type\":\"location\",\"id\":\"889207774458960\",\"value\":\"Novo Terra\\u00e7o\"},{\"type\":\"location\",\"id\":\"456223191105165\",\"value\":\"COC Araraquara\"},{\"type\":\"location\",\"id\":\"151124121640293\",\"value\":\"Santa Casa de Araraquara\"},{\"type\":\"people\",\"id\":\"522763222\",\"value\":\"lbfararaquara\"},{\"type\":\"people\",\"id\":\"3537841540\",\"value\":\"coc.araraquara\"},{\"type\":\"people\",\"id\":\"5503926147\",\"value\":\"ficadicaararaquara\"},{\"type\":\"people\",\"id\":\"2305232200\",\"value\":\"objetivo.araraquara\"},{\"type\":\"people\",\"id\":\"8355554687\",\"value\":\"speed_burger_araraquara\"},{\"type\":\"people\",\"id\":\"1211629862\",\"value\":\"equilibrio_araraquara\"},{\"type\":\"people\",\"id\":\"1984610528\",\"value\":\"liquido_araraquara\"},{\"type\":\"people\",\"id\":\"5882812157\",\"value\":\"emagresee.araraquara\"},{\"type\":\"people\",\"id\":\"341590323\",\"value\":\"outletlingerie_araraquara\"},{\"type\":\"people\",\"id\":\"5506979418\",\"value\":\"brooksararaquara\"}]','{\"enabled\":false}','very_fast',0,'00:00:00','00:00:00',1,'2018-08-09 23:59:59','2030-12-12 23:59:59','2018-08-09 23:57:51','{}'),(5,1,17,'[{\"type\":\"hashtag\",\"id\":\"araraquara\",\"value\":\"araraquara\"},{\"type\":\"hashtag\",\"id\":\"mtbararaquara\",\"value\":\"mtbararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquarasp\",\"value\":\"araraquarasp\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umt\",\"value\":\"araraquara\\u00e9umt\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umtes\\u00e3o\",\"value\":\"araraquara\\u00e9umtes\\u00e3o\"},{\"type\":\"hashtag\",\"id\":\"araraquaracity\",\"value\":\"araraquaracity\"},{\"type\":\"hashtag\",\"id\":\"araraquararock\",\"value\":\"araraquararock\"},{\"type\":\"hashtag\",\"id\":\"araraquarafood\",\"value\":\"araraquarafood\"},{\"type\":\"hashtag\",\"id\":\"araraquara200anos\",\"value\":\"araraquara200anos\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umtesao\",\"value\":\"araraquara\\u00e9umtesao\"},{\"type\":\"hashtag\",\"id\":\"araraquaratattoo\",\"value\":\"araraquaratattoo\"},{\"type\":\"hashtag\",\"id\":\"araraquaraeumtesao\",\"value\":\"araraquaraeumtesao\"},{\"type\":\"hashtag\",\"id\":\"araraquarafitness\",\"value\":\"araraquarafitness\"},{\"type\":\"hashtag\",\"id\":\"unespararaquara\",\"value\":\"unespararaquara\"},{\"type\":\"hashtag\",\"id\":\"lafamiliatattooararaquara\",\"value\":\"lafamiliatattooararaquara\"},{\"type\":\"hashtag\",\"id\":\"crossfitararaquara\",\"value\":\"crossfitararaquara\"},{\"type\":\"hashtag\",\"id\":\"sescararaquara\",\"value\":\"sescararaquara\"},{\"type\":\"hashtag\",\"id\":\"euindicochilenotattooararaquara\",\"value\":\"euindicochilenotattooararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaracountryfest\",\"value\":\"araraquaracountryfest\"},{\"type\":\"hashtag\",\"id\":\"agitoararaquara\",\"value\":\"agitoararaquara\"},{\"type\":\"hashtag\",\"id\":\"mangaverdeararaquara\",\"value\":\"mangaverdeararaquara\"},{\"type\":\"location\",\"id\":\"108259652527599\",\"value\":\"Araraquara\"},{\"type\":\"location\",\"id\":\"821338214672792\",\"value\":\"Araraquara Morada do Sol\"},{\"type\":\"location\",\"id\":\"303165766365752\",\"value\":\"Vila Xavier, Araraquara\"},{\"type\":\"location\",\"id\":\"199417360164391\",\"value\":\"Sesc Araraquara\"},{\"type\":\"people\",\"id\":\"3537841540\",\"value\":\"coc.araraquara\"},{\"type\":\"people\",\"id\":\"828346497\",\"value\":\"shoppingjaraguaararaquara\"},{\"type\":\"people\",\"id\":\"1211629862\",\"value\":\"equilibrio_araraquara\"},{\"type\":\"people\",\"id\":\"1811047067\",\"value\":\"clubemelissaararaquara\"},{\"type\":\"people\",\"id\":\"3285321255\",\"value\":\"ointeroficial\"},{\"type\":\"people\",\"id\":\"7336970604\",\"value\":\"bardasextaararaquara\"},{\"type\":\"people\",\"id\":\"5882812157\",\"value\":\"emagresee.araraquara\"},{\"type\":\"people\",\"id\":\"12347490\",\"value\":\"araraquara\"},{\"type\":\"people\",\"id\":\"7709091836\",\"value\":\"maxgym_araraquara\"},{\"type\":\"people\",\"id\":\"3205088729\",\"value\":\"espacocafe.araraquara\"},{\"type\":\"people\",\"id\":\"7291582533\",\"value\":\"brexodoararaquara\"},{\"type\":\"people\",\"id\":\"7584920120\",\"value\":\"lojamfararaquara\"},{\"type\":\"people\",\"id\":\"5506979418\",\"value\":\"brooksararaquara\"},{\"type\":\"people\",\"id\":\"1984610528\",\"value\":\"liquido_araraquara\"},{\"type\":\"people\",\"id\":\"6248577306\",\"value\":\"protocoloar\"},{\"type\":\"people\",\"id\":\"6679481031\",\"value\":\"araraquaraemcena\"},{\"type\":\"people\",\"id\":\"8388203645\",\"value\":\"rotaryclubararaquararacarmo\"},{\"type\":\"people\",\"id\":\"5498281494\",\"value\":\"moranaararaquara\"},{\"type\":\"people\",\"id\":\"7286626111\",\"value\":\"almanaque.araraquara\"},{\"type\":\"people\",\"id\":\"5850197759\",\"value\":\"sncararaquara\"},{\"type\":\"people\",\"id\":\"4455506709\",\"value\":\"boladeneveararaquara\"}]','{\"enabled\":false}','auto',0,'00:00:00','00:00:00',1,'2018-08-10 00:40:37','2030-12-12 23:59:59','2018-08-10 00:35:01','{}');
/*!40000 ALTER TABLE `np_auto_like_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_repost_log`
--

DROP TABLE IF EXISTS `np_auto_repost_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_repost_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `original_media_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `is_removable` tinyint(1) NOT NULL,
  `remove_scheduled` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `remove_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  KEY `original_media_code` (`original_media_code`),
  CONSTRAINT `ibfk_5b57c1cad30c6` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c1cad444f` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_repost_log`
--

LOCK TABLES `np_auto_repost_log` WRITE;
/*!40000 ALTER TABLE `np_auto_repost_log` DISABLE KEYS */;
INSERT INTO `np_auto_repost_log` VALUES (1,2,3,'success','Blle-J1nov7','{\"trigger\":{\"type\":\"people\",\"id\":\"5446064558\",\"value\":\"chillibeansararaquara\"},\"grabbed\":{\"media_id\":\"1830005036162124795_5446064558\",\"media_code\":\"Blle-J1nov7\",\"media_type\":1,\"media_thumb\":\"https:\\/\\/scontent-gru2-1.cdninstagram.com\\/vp\\/7981c9e6bfc7483499eabca98d46921e\\/5BFF2B7B\\/t51.2885-15\\/e35\\/37063605_686633151675461_5745399535933325312_n.jpg?se=7&ig_cache_key=MTgzMDAwNTAzNjE2MjEyNDc5NQ%3D%3D.2\",\"user\":{\"pk\":\"5446064558\",\"username\":\"chillibeansararaquara\",\"full_name\":\"Chilli Beans Araraquara\"}},\"reposted\":{\"upload_id\":\"171537398771016\",\"media_pk\":\"1841006832791066899\",\"media_id\":\"1841006832791066899_8322540155\",\"media_code\":\"BmMkfXZlBkT\"}}','2018-08-07 23:39:01',0,'2018-08-07 23:39:01',0,'2018-08-07 23:39:01');
/*!40000 ALTER TABLE `np_auto_repost_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_repost_schedule`
--

DROP TABLE IF EXISTS `np_auto_repost_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_repost_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `target` text COLLATE utf8_unicode_ci NOT NULL,
  `caption` text COLLATE utf8_unicode_ci NOT NULL,
  `remove_delay` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `speed` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `daily_pause` tinyint(1) NOT NULL,
  `daily_pause_from` time NOT NULL,
  `daily_pause_to` time NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `schedule_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `last_action_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `ibfk_5b57c1cad09c6` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c1cad1d49` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_repost_schedule`
--

LOCK TABLES `np_auto_repost_schedule` WRITE;
/*!40000 ALTER TABLE `np_auto_repost_schedule` DISABLE KEYS */;
INSERT INTO `np_auto_repost_schedule` VALUES (1,2,3,'[{\"type\":\"location\",\"id\":\"108259652527599\",\"value\":\"Araraquara\"},{\"type\":\"people\",\"id\":\"797137842\",\"value\":\"american.burger.araraquara\"},{\"type\":\"people\",\"id\":\"8056091042\",\"value\":\"araraquara_rock\"},{\"type\":\"people\",\"id\":\"5446064558\",\"value\":\"chillibeansararaquara\"}]','{{caption}} Confira as melhores oportunidades!','0','auto',0,'00:00:00','00:00:00',1,'2018-08-08 00:56:21','2030-12-12 23:59:59','2018-08-07 23:38:56'),(2,1,16,'[{\"type\":\"hashtag\",\"id\":\"araraquara\",\"value\":\"araraquara\"},{\"type\":\"hashtag\",\"id\":\"mtbararaquara\",\"value\":\"mtbararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaracity\",\"value\":\"araraquaracity\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umt\",\"value\":\"araraquara\\u00e9umt\"},{\"type\":\"hashtag\",\"id\":\"araraquarafitness\",\"value\":\"araraquarafitness\"},{\"type\":\"hashtag\",\"id\":\"unespararaquara\",\"value\":\"unespararaquara\"},{\"type\":\"hashtag\",\"id\":\"vempral\\u00edquidoararaquara\",\"value\":\"vempral\\u00edquidoararaquara\"},{\"type\":\"hashtag\",\"id\":\"mangaverdeararaquara\",\"value\":\"mangaverdeararaquara\"},{\"type\":\"hashtag\",\"id\":\"naoparaararaquara\",\"value\":\"naoparaararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaraeregi\\u00e3o\",\"value\":\"araraquaraeregi\\u00e3o\"},{\"type\":\"hashtag\",\"id\":\"araraquaracountryfest\",\"value\":\"araraquaracountryfest\"},{\"type\":\"hashtag\",\"id\":\"araraquaraemcena\",\"value\":\"araraquaraemcena\"},{\"type\":\"hashtag\",\"id\":\"yogaararaquara\",\"value\":\"yogaararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquarafeet\",\"value\":\"araraquarafeet\"},{\"type\":\"hashtag\",\"id\":\"interararaquara\",\"value\":\"interararaquara\"},{\"type\":\"hashtag\",\"id\":\"clubemelissaararaquara\",\"value\":\"clubemelissaararaquara\"},{\"type\":\"location\",\"id\":\"281514025220988\",\"value\":\"R\\u00e1dio Cultura Araraquara\"},{\"type\":\"location\",\"id\":\"129796860433517\",\"value\":\"Padaria P\\u00e3o da Terra Araraquara\"},{\"type\":\"location\",\"id\":\"279699048751883\",\"value\":\"Senac Araraquara\"},{\"type\":\"location\",\"id\":\"188009621283507\",\"value\":\"R\\u00e1dio Morada Araraquara\"},{\"type\":\"location\",\"id\":\"339115442792829\",\"value\":\"Senai Araraquara\"},{\"type\":\"location\",\"id\":\"209925759377949\",\"value\":\"Uniara - Universidade de Araraquara\"},{\"type\":\"location\",\"id\":\"174170962659903\",\"value\":\"Par\\u00f3quia Sagrada Fam\\u00edlia - Araraquara\"},{\"type\":\"location\",\"id\":\"137424926420085\",\"value\":\"Cacha\\u00e7aria \\u00c1gua Doce Araraquara\"},{\"type\":\"location\",\"id\":\"225704610954125\",\"value\":\"FCLAR - Faculdade de Ci\\u00eancias e Letras da Unesp Araraquara\"},{\"type\":\"location\",\"id\":\"889207774458960\",\"value\":\"Novo Terra\\u00e7o\"},{\"type\":\"location\",\"id\":\"251854168197653\",\"value\":\"Bar do Portugu\\u00eas - Araraquara\"},{\"type\":\"location\",\"id\":\"516865911660204\",\"value\":\"Sakana Araraquara\"},{\"type\":\"location\",\"id\":\"425894714101094\",\"value\":\"Universidade Paulista Unip Araraquara\"},{\"type\":\"location\",\"id\":\"209257532453661\",\"value\":\"Heineken Brasil Araraquara\"},{\"type\":\"location\",\"id\":\"678535868886030\",\"value\":\"Hotel Dan Inn Araraquara\"},{\"type\":\"location\",\"id\":\"1425692921081791\",\"value\":\"Rock & Ribs Lounge Araraquara\"},{\"type\":\"location\",\"id\":\"1601057950223054\",\"value\":\"Espa\\u00e7o Caf\\u00e9 Araraquara\"},{\"type\":\"location\",\"id\":\"257214134326689\",\"value\":\"SESI Araraquara\"},{\"type\":\"location\",\"id\":\"159481290914152\",\"value\":\"Clube N\\u00e1utico Araraquara\"},{\"type\":\"location\",\"id\":\"303165766365752\",\"value\":\"Vila Xavier, Araraquara\"},{\"type\":\"location\",\"id\":\"203730886337123\",\"value\":\"Universidade de Araraquara\"},{\"type\":\"people\",\"id\":\"5503926147\",\"value\":\"ficadicaararaquara\"},{\"type\":\"people\",\"id\":\"8355554687\",\"value\":\"speed_burger_araraquara\"},{\"type\":\"people\",\"id\":\"2305232200\",\"value\":\"objetivo.araraquara\"},{\"type\":\"people\",\"id\":\"12347490\",\"value\":\"araraquara\"},{\"type\":\"people\",\"id\":\"1211629862\",\"value\":\"equilibrio_araraquara\"},{\"type\":\"people\",\"id\":\"5882812157\",\"value\":\"emagresee.araraquara\"}]','{{rubrica}}','0','auto',0,'00:00:00','00:00:00',0,'2018-08-10 00:01:53','2030-12-12 23:59:59','2018-08-10 00:00:53'),(3,1,17,'[{\"type\":\"hashtag\",\"id\":\"araraquara\",\"value\":\"araraquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaracity\",\"value\":\"araraquaracity\"},{\"type\":\"hashtag\",\"id\":\"mtbararaquara\",\"value\":\"mtbararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquarasp\",\"value\":\"araraquarasp\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umt\",\"value\":\"araraquara\\u00e9umt\"},{\"type\":\"hashtag\",\"id\":\"araraquararock\",\"value\":\"araraquararock\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umtes\\u00e3o\",\"value\":\"araraquara\\u00e9umtes\\u00e3o\"},{\"type\":\"hashtag\",\"id\":\"araraquarafood\",\"value\":\"araraquarafood\"},{\"type\":\"hashtag\",\"id\":\"araraquaratattoo\",\"value\":\"araraquaratattoo\"},{\"type\":\"hashtag\",\"id\":\"araraquara200anos\",\"value\":\"araraquara200anos\"},{\"type\":\"hashtag\",\"id\":\"araraquara\\u00e9umtesao\",\"value\":\"araraquara\\u00e9umtesao\"},{\"type\":\"hashtag\",\"id\":\"araraquarafitness\",\"value\":\"araraquarafitness\"},{\"type\":\"hashtag\",\"id\":\"araraquaraeumtesao\",\"value\":\"araraquaraeumtesao\"},{\"type\":\"hashtag\",\"id\":\"lafamiliatattooararaquara\",\"value\":\"lafamiliatattooararaquara\"},{\"type\":\"hashtag\",\"id\":\"unespararaquara\",\"value\":\"unespararaquara\"},{\"type\":\"hashtag\",\"id\":\"agitoararaquara\",\"value\":\"agitoararaquara\"},{\"type\":\"hashtag\",\"id\":\"crossfitararaquara\",\"value\":\"crossfitararaquara\"},{\"type\":\"hashtag\",\"id\":\"sescararaquara\",\"value\":\"sescararaquara\"},{\"type\":\"hashtag\",\"id\":\"euindicochilenotattooararaquara\",\"value\":\"euindicochilenotattooararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaramoradadosol\",\"value\":\"araraquaramoradadosol\"},{\"type\":\"hashtag\",\"id\":\"araraquaracountryfest\",\"value\":\"araraquaracountryfest\"},{\"type\":\"hashtag\",\"id\":\"araraquarafeet\",\"value\":\"araraquarafeet\"},{\"type\":\"hashtag\",\"id\":\"vempral\\u00edquidoararaquara\",\"value\":\"vempral\\u00edquidoararaquara\"},{\"type\":\"hashtag\",\"id\":\"mangaverdeararaquara\",\"value\":\"mangaverdeararaquara\"},{\"type\":\"hashtag\",\"id\":\"naoparaararaquara\",\"value\":\"naoparaararaquara\"},{\"type\":\"hashtag\",\"id\":\"araraquaraemcena\",\"value\":\"araraquaraemcena\"},{\"type\":\"location\",\"id\":\"108259652527599\",\"value\":\"Araraquara\"},{\"type\":\"location\",\"id\":\"821338214672792\",\"value\":\"Araraquara Morada do Sol\"},{\"type\":\"location\",\"id\":\"477547029035479\",\"value\":\"Shopping Jaragu\\u00e1 Concei\\u00e7\\u00e3o\"},{\"type\":\"location\",\"id\":\"109101979112042\",\"value\":\"Centro Tur\\u00e9n, Portuguesa, Venezuela\"},{\"type\":\"location\",\"id\":\"199417360164391\",\"value\":\"Sesc Araraquara\"},{\"type\":\"location\",\"id\":\"203730886337123\",\"value\":\"Universidade de Araraquara\"},{\"type\":\"location\",\"id\":\"303165766365752\",\"value\":\"Vila Xavier, Araraquara\"},{\"type\":\"location\",\"id\":\"159481290914152\",\"value\":\"Clube N\\u00e1utico Araraquara\"},{\"type\":\"location\",\"id\":\"257214134326689\",\"value\":\"SESI Araraquara\"},{\"type\":\"location\",\"id\":\"1601057950223054\",\"value\":\"Espa\\u00e7o Caf\\u00e9 Araraquara\"},{\"type\":\"location\",\"id\":\"1425692921081791\",\"value\":\"Rock & Ribs Lounge Araraquara\"},{\"type\":\"location\",\"id\":\"678535868886030\",\"value\":\"Hotel Dan Inn Araraquara\"},{\"type\":\"location\",\"id\":\"209257532453661\",\"value\":\"Heineken Brasil Araraquara\"},{\"type\":\"location\",\"id\":\"425894714101094\",\"value\":\"Universidade Paulista Unip Araraquara\"},{\"type\":\"location\",\"id\":\"516865911660204\",\"value\":\"Sakana Araraquara\"},{\"type\":\"location\",\"id\":\"281514025220988\",\"value\":\"R\\u00e1dio Cultura Araraquara\"},{\"type\":\"location\",\"id\":\"251854168197653\",\"value\":\"Bar do Portugu\\u00eas - Araraquara\"},{\"type\":\"location\",\"id\":\"129796860433517\",\"value\":\"Padaria P\\u00e3o da Terra Araraquara\"},{\"type\":\"location\",\"id\":\"279699048751883\",\"value\":\"Senac Araraquara\"},{\"type\":\"location\",\"id\":\"188009621283507\",\"value\":\"R\\u00e1dio Morada Araraquara\"},{\"type\":\"location\",\"id\":\"339115442792829\",\"value\":\"Senai Araraquara\"},{\"type\":\"location\",\"id\":\"209925759377949\",\"value\":\"Uniara - Universidade de Araraquara\"},{\"type\":\"location\",\"id\":\"174170962659903\",\"value\":\"Par\\u00f3quia Sagrada Fam\\u00edlia - Araraquara\"},{\"type\":\"location\",\"id\":\"137424926420085\",\"value\":\"Cacha\\u00e7aria \\u00c1gua Doce Araraquara\"},{\"type\":\"people\",\"id\":\"3537841540\",\"value\":\"coc.araraquara\"},{\"type\":\"people\",\"id\":\"828346497\",\"value\":\"shoppingjaraguaararaquara\"},{\"type\":\"people\",\"id\":\"1211629862\",\"value\":\"equilibrio_araraquara\"},{\"type\":\"people\",\"id\":\"1811047067\",\"value\":\"clubemelissaararaquara\"},{\"type\":\"people\",\"id\":\"3285321255\",\"value\":\"ointeroficial\"},{\"type\":\"people\",\"id\":\"7336970604\",\"value\":\"bardasextaararaquara\"},{\"type\":\"people\",\"id\":\"12347490\",\"value\":\"araraquara\"},{\"type\":\"people\",\"id\":\"7709091836\",\"value\":\"maxgym_araraquara\"},{\"type\":\"people\",\"id\":\"5882812157\",\"value\":\"emagresee.araraquara\"},{\"type\":\"people\",\"id\":\"3205088729\",\"value\":\"espacocafe.araraquara\"},{\"type\":\"people\",\"id\":\"7291582533\",\"value\":\"brexodoararaquara\"},{\"type\":\"people\",\"id\":\"7584920120\",\"value\":\"lojamfararaquara\"},{\"type\":\"people\",\"id\":\"5506979418\",\"value\":\"brooksararaquara\"},{\"type\":\"people\",\"id\":\"1984610528\",\"value\":\"liquido_araraquara\"},{\"type\":\"people\",\"id\":\"6248577306\",\"value\":\"protocoloar\"},{\"type\":\"people\",\"id\":\"6679481031\",\"value\":\"araraquaraemcena\"},{\"type\":\"people\",\"id\":\"8388203645\",\"value\":\"rotaryclubararaquararacarmo\"},{\"type\":\"people\",\"id\":\"5498281494\",\"value\":\"moranaararaquara\"},{\"type\":\"people\",\"id\":\"7286626111\",\"value\":\"almanaque.araraquara\"},{\"type\":\"people\",\"id\":\"5850197759\",\"value\":\"sncararaquara\"},{\"type\":\"people\",\"id\":\"4455506709\",\"value\":\"boladeneveararaquara\"},{\"type\":\"people\",\"id\":\"218406369\",\"value\":\"helenareisl\"},{\"type\":\"people\",\"id\":\"3278578237\",\"value\":\"sanmartinararaquaracentro\"},{\"type\":\"people\",\"id\":\"2343067500\",\"value\":\"lpm_araraquara\"}]','{{caption}}','0','very_fast',0,'00:00:00','00:00:00',1,'2018-08-10 00:46:23','2030-12-12 23:59:59','2018-08-10 00:45:23');
/*!40000 ALTER TABLE `np_auto_repost_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_unfollow_log`
--

DROP TABLE IF EXISTS `np_auto_unfollow_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_unfollow_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `unfollowed_user_pk` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  KEY `unfollowed_user_pk` (`unfollowed_user_pk`),
  CONSTRAINT `ibfk_5b57c1d9bf980` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c1d9bf9d4` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_unfollow_log`
--

LOCK TABLES `np_auto_unfollow_log` WRITE;
/*!40000 ALTER TABLE `np_auto_unfollow_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `np_auto_unfollow_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_auto_unfollow_schedule`
--

DROP TABLE IF EXISTS `np_auto_unfollow_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_auto_unfollow_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `speed` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `daily_pause` tinyint(1) NOT NULL,
  `daily_pause_from` time NOT NULL,
  `daily_pause_to` time NOT NULL,
  `keep_followers` tinyint(1) NOT NULL,
  `whitelist` text COLLATE utf8_unicode_ci NOT NULL,
  `source` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `schedule_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `last_action_date` datetime NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `ibfk_5b57c1d9bf8cc` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b57c1d9bf92c` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_auto_unfollow_schedule`
--

LOCK TABLES `np_auto_unfollow_schedule` WRITE;
/*!40000 ALTER TABLE `np_auto_unfollow_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `np_auto_unfollow_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_captions`
--

DROP TABLE IF EXISTS `np_captions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_captions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `caption` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `captions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_captions`
--

LOCK TABLES `np_captions` WRITE;
/*!40000 ALTER TABLE `np_captions` DISABLE KEYS */;
INSERT INTO `np_captions` VALUES (1,1,'Quem somos',':heart_eyes:NRV CONSTRUTORA.\r\nCasas a partir R$125.000,000\r\n:motorcycle:www.nrvconstrutora.com.br','2018-08-10 01:44:09');
/*!40000 ALTER TABLE `np_captions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_files`
--

DROP TABLE IF EXISTS `np_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `info` text COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_files`
--

LOCK TABLES `np_files` WRITE;
/*!40000 ALTER TABLE `np_files` DISABLE KEYS */;
INSERT INTO `np_files` VALUES (1,2,'odontopediatria-quando-levar-a-crianca-ao-dentista-1024x682.jpeg','','pinozuke-5b57d60e7e31e.jpeg','66204','2018-07-25 01:44:46'),(2,1,'logo_gerencia_insta.png','','widexori-5b57e2a0ec552.png','3120','2018-07-25 02:38:24'),(3,2,'30X07.png','','locedila-5b5f2304a3564.jpg','998266','2018-07-30 14:39:00'),(4,5,'post.jpg','','leyufesi-5b6240693d0ac.jpg','271312','2018-08-01 23:21:13'),(5,1,'19x07.png','','pedaluti-5b69aa67eab41.jpg','982010','2018-08-07 14:19:20'),(6,1,'Financie_seu_sonho.png','','defunube-5b69aad9277a2.jpg','1274939','2018-08-07 14:21:13'),(7,9,'app1.png','','feriwuso-5b69b055df513.jpg','529419','2018-08-07 14:44:38'),(8,10,'4b39d7266beb5551063b9ea8605890ab.jpg','','wuseketi-5b69d8970fdeb.jpeg','85344','2018-08-07 17:36:23'),(9,1,'google-1.png','','mariwufe-5b6ac77fb83b3.jpg','1177528','2018-08-08 10:35:43'),(10,1,'07x08.png','','cujalina-5b6ac7c9ddbd8.jpg','568058','2018-08-08 10:36:58'),(11,1,'04X07.png','','levugidu-5b6ac816007f2.jpg','707750','2018-08-08 10:38:14'),(12,1,'14x07.png','','gosalaxa-5b6ac8333a6c8.jpg','970798','2018-08-08 10:38:43'),(13,11,'5.png','','jinezowe-5b6b1d8fcf127.jpg','260065','2018-08-08 16:42:56'),(14,12,'1557c7d41c910da.jpg','','fusiginu-5b6b41eef00ac.jpg','60380','2018-08-08 19:18:07'),(15,17,'cachorro.png','','faguloto-5b6b9d1b93120.jpg','895284','2018-08-09 01:47:07'),(16,19,'b9ce8e99695af80ec29b4ee87f02d986.jpg','','namigimo-5b6c1edfefbae.jpg','208325','2018-08-09 11:00:48'),(17,1,'09x08.png','','ditibusi-5b6c3ae7912ee.jpg','899420','2018-08-09 13:00:23'),(18,21,'http flow.png','','koresise-5b6ca76c87c72.jpg','39396','2018-08-09 20:43:24'),(19,1,'1.jpg','','bejovoge-5b6cd1f1e484f.jpg','98600','2018-08-09 23:44:49'),(20,1,'2.jpg','','devegici-5b6cd215783a1.jpg','125615','2018-08-09 23:45:25'),(21,1,'3.jpg','','copijizo-5b6cd24dcff5b.jpg','119790','2018-08-09 23:46:21'),(22,1,'4.jpg','','puxutipa-5b6cd2735c8a7.jpg','119537','2018-08-09 23:46:59'),(23,1,'5.jpg','','fohusoxu-5b6cd2bd3fd96.jpg','221128','2018-08-09 23:48:13'),(24,1,'6.jpg','','gowofito-5b6cd2eea5475.jpg','123938','2018-08-09 23:49:02'),(25,1,'2.png','','tekofako-5b6cdace1d71f.jpg','589367','2018-08-10 00:22:38'),(26,1,'1.png','','gesumuze-5b6cdaecdc648.jpg','298181','2018-08-10 00:23:08'),(27,1,'3.png','','kusopaka-5b6cdb1b2a2f0.jpg','500150','2018-08-10 00:23:55'),(28,1,'4.png','','sibaxore-5b6cdbce0a8e5.jpg','724312','2018-08-10 00:26:54'),(29,1,'10x08x2018.png','','silecabi-5b6d81ece8e2b.jpg','658663','2018-08-10 12:15:41');
/*!40000 ALTER TABLE `np_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_general_data`
--

DROP TABLE IF EXISTS `np_general_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_general_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_general_data`
--

LOCK TABLES `np_general_data` WRITE;
/*!40000 ALTER TABLE `np_general_data` DISABLE KEYS */;
INSERT INTO `np_general_data` VALUES (1,'settings','{\"site_name\":\"Gerenciainsta\",\"site_description\":\"Agendamento de postagens no Instagram.\",\"site_keywords\":\"agendamento de post, instagram, auto post instagram, agenda instagram\",\"currency\":\"BRL\",\"proxy\":true,\"user_proxy\":true,\"geonamesorg_username\":\"\",\"logomark\":\"\",\"logotype\":\"\"}'),(2,'integrations','{\"dropbox\":{\"api_key\":\"\"},\"google\":{\"api_key\":\"\",\"client_id\":\"\",\"analytics\":{\"property_id\":\"UA-122809154-1\"}},\"onedrive\":{\"client_id\":\"\"},\"paypal\":{\"client_id\":\"AauPUnrgHGmXs7EOSdqam2-_Frr5ZYfGMUETCsgJuLGraNBWhzU4iceCjb4ADonDoaClEMAmSDISzSHb\",\"client_secret\":\"EHfuCaT3KgG0tTLgbp-XHdRBVJpoa0xIC9tINgT2Ax_B0OsAoMkJ1qGqLt6KQTyX7wBhvtlD5MvPJKrH\",\"environment\":\"live\"},\"stripe\":{\"environment\":\"sandbox\",\"publishable_key\":\"\",\"secret_key\":\"\"},\"facebook\":{\"app_id\":\"\",\"app_secret\":\"\"}}'),(3,'free-trial','{\"size\":30,\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}'),(4,'email-settings','{\"smtp\":{\"host\":\"\",\"port\":\"\",\"encryption\":\"\",\"auth\":false,\"username\":\"\",\"password\":\"\",\"from\":\"\"},\"notifications\":{\"emails\":\"toledo.connect@gmail.com\",\"new_user\":true,\"new_payment\":true},\"email_verification\":false}'),(5,'plugin-welcomedm-settings','{\"speeds\":{\"very_slow\":1,\"slow\":1,\"medium\":1,\"fast\":1,\"very_fast\":1},\"random_delay\":true}');
/*!40000 ALTER TABLE `np_general_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_options`
--

DROP TABLE IF EXISTS `np_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_options` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `option_name` varchar(255) NOT NULL,
  `option_value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_options`
--

LOCK TABLES `np_options` WRITE;
/*!40000 ALTER TABLE `np_options` DISABLE KEYS */;
INSERT INTO `np_options` VALUES (3,'np_active_theme_idname','default');
/*!40000 ALTER TABLE `np_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_orders`
--

DROP TABLE IF EXISTS `np_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `payment_gateway` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `payment_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `total` double(10,2) NOT NULL,
  `paid` double(10,2) NOT NULL,
  `currency` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_orders`
--

LOCK TABLES `np_orders` WRITE;
/*!40000 ALTER TABLE `np_orders` DISABLE KEYS */;
INSERT INTO `np_orders` VALUES (1,1,'{\"package\":{\"id\":\"3\",\"title\":\"Plano Senior\",\"monthly_price\":\"17.99\",\"annual_price\":\"165.79\",\"settings\":\"{\\\"storage\\\":{\\\"total\\\":\\\"300.00\\\",\\\"file\\\":\\\"50.00\\\"},\\\"max_accounts\\\":-1,\\\"file_pickers\\\":{\\\"dropbox\\\":true,\\\"onedrive\\\":true,\\\"google_drive\\\":true},\\\"post_types\\\":{\\\"timeline_photo\\\":true,\\\"timeline_video\\\":true,\\\"story_photo\\\":true,\\\"story_video\\\":true,\\\"album_photo\\\":true,\\\"album_video\\\":true},\\\"spintax\\\":true,\\\"modules\\\":null}\"},\"plan\":\"monthly\",\"is_subscription\":false,\"is_subscription_payment\":false,\"subscribe_to_changes\":true,\"applied_settings\":{\"storage\":{\"total\":\"300.00\",\"file\":\"50.00\"},\"max_accounts\":-1,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":null}}','payment_processing','paypal','',17.99,0.00,'BRL','2018-07-25 01:25:57'),(2,1,'{\"package\":{\"id\":\"3\",\"title\":\"Plano Senior\",\"monthly_price\":\"17.99\",\"annual_price\":\"165.79\",\"settings\":\"{\\\"storage\\\":{\\\"total\\\":\\\"300.00\\\",\\\"file\\\":\\\"50.00\\\"},\\\"max_accounts\\\":-1,\\\"file_pickers\\\":{\\\"dropbox\\\":true,\\\"onedrive\\\":true,\\\"google_drive\\\":true},\\\"post_types\\\":{\\\"timeline_photo\\\":true,\\\"timeline_video\\\":true,\\\"story_photo\\\":true,\\\"story_video\\\":true,\\\"album_photo\\\":true,\\\"album_video\\\":true},\\\"spintax\\\":true,\\\"modules\\\":null}\"},\"plan\":\"monthly\",\"is_subscription\":false,\"is_subscription_payment\":false,\"subscribe_to_changes\":true,\"applied_settings\":{\"storage\":{\"total\":\"300.00\",\"file\":\"50.00\"},\"max_accounts\":-1,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":null}}','payment_processing','paypal','',17.99,0.00,'BRL','2018-07-25 01:29:10'),(3,2,'{\"package\":{\"id\":\"1\",\"title\":\"Junior\",\"monthly_price\":\"4.99\",\"annual_price\":\"49.00\",\"settings\":\"{\\\"storage\\\":{\\\"total\\\":\\\"150.00\\\",\\\"file\\\":\\\"15.00\\\"},\\\"max_accounts\\\":1,\\\"file_pickers\\\":{\\\"dropbox\\\":true,\\\"onedrive\\\":true,\\\"google_drive\\\":true},\\\"post_types\\\":{\\\"timeline_photo\\\":true,\\\"timeline_video\\\":false,\\\"story_photo\\\":true,\\\"story_video\\\":false,\\\"album_photo\\\":true,\\\"album_video\\\":false},\\\"spintax\\\":false,\\\"modules\\\":null}\"},\"plan\":\"monthly\",\"is_subscription\":false,\"is_subscription_payment\":false,\"subscribe_to_changes\":false,\"applied_settings\":{\"storage\":{\"total\":\"150.00\",\"file\":\"15.00\"},\"max_accounts\":1,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":false,\"story_photo\":true,\"story_video\":false,\"album_photo\":true,\"album_video\":false},\"spintax\":false,\"modules\":null}}','payment_processing','paypal','',4.99,0.00,'BRL','2018-07-25 01:41:09'),(4,2,'{\"package\":{\"id\":\"2\",\"title\":\"Plano Pleno\",\"monthly_price\":\"79.00\",\"annual_price\":\"799.00\",\"settings\":\"{\\\"storage\\\":{\\\"total\\\":\\\"250.00\\\",\\\"file\\\":\\\"30.00\\\"},\\\"max_accounts\\\":3,\\\"file_pickers\\\":{\\\"dropbox\\\":true,\\\"onedrive\\\":true,\\\"google_drive\\\":true},\\\"post_types\\\":{\\\"timeline_photo\\\":true,\\\"timeline_video\\\":true,\\\"story_photo\\\":true,\\\"story_video\\\":true,\\\"album_photo\\\":true,\\\"album_video\\\":true},\\\"spintax\\\":true,\\\"modules\\\":[\\\"auto-repost\\\",\\\"auto-unfollow\\\"]}\"},\"plan\":\"monthly\",\"is_subscription\":false,\"is_subscription_payment\":false,\"subscribe_to_changes\":false,\"applied_settings\":{\"storage\":{\"total\":\"250.00\",\"file\":\"30.00\"},\"max_accounts\":3,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\"]}}','payment_processing','paypal','',79.00,0.00,'BRL','2018-08-07 01:51:18');
/*!40000 ALTER TABLE `np_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_packages`
--

DROP TABLE IF EXISTS `np_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `monthly_price` double(10,2) NOT NULL,
  `annual_price` float(10,2) NOT NULL,
  `settings` text COLLATE utf8_unicode_ci NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_packages`
--

LOCK TABLES `np_packages` WRITE;
/*!40000 ALTER TABLE `np_packages` DISABLE KEYS */;
INSERT INTO `np_packages` VALUES (1,'Junior',59.00,599.00,'{\"storage\":{\"total\":\"150.00\",\"file\":\"15.00\"},\"max_accounts\":10,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}',1,'2017-03-18 19:22:44'),(2,'Plano Pleno',79.00,799.00,'{\"storage\":{\"total\":\"250.00\",\"file\":\"30.00\"},\"max_accounts\":20,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}',1,'2017-03-18 19:29:19'),(3,'Plano Senior',89.00,899.00,'{\"storage\":{\"total\":\"300.00\",\"file\":\"50.00\"},\"max_accounts\":50,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}',1,'2017-03-18 19:29:43');
/*!40000 ALTER TABLE `np_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_plugins`
--

DROP TABLE IF EXISTS `np_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idname` (`idname`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_plugins`
--

LOCK TABLES `np_plugins` WRITE;
/*!40000 ALTER TABLE `np_plugins` DISABLE KEYS */;
INSERT INTO `np_plugins` VALUES (1,'auto-comment',1),(2,'auto-follow',1),(3,'auto-like',1),(4,'auto-repost',1),(5,'auto-unfollow',1),(6,'welcomedm',1);
/*!40000 ALTER TABLE `np_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_posts`
--

DROP TABLE IF EXISTS `np_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `caption` text COLLATE utf8_unicode_ci NOT NULL,
  `first_comment` text COLLATE utf8_unicode_ci NOT NULL,
  `location` text COLLATE utf8_unicode_ci NOT NULL,
  `media_ids` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remove_media` text COLLATE utf8_unicode_ci NOT NULL,
  `account_id` int(11) NOT NULL,
  `is_scheduled` tinyint(1) NOT NULL,
  `create_date` datetime NOT NULL,
  `schedule_date` datetime NOT NULL,
  `publish_date` datetime NOT NULL,
  `is_hidden` tinyint(1) NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_posts`
--

LOCK TABLES `np_posts` WRITE;
/*!40000 ALTER TABLE `np_posts` DISABLE KEYS */;
INSERT INTO `np_posts` VALUES (2,'published',2,'timeline','','','','3','0',3,0,'2018-07-30 14:39:17','2018-07-30 14:39:17','2018-07-30 14:39:21',0,'{\"upload_id\":\"657557453946310\",\"pk\":\"1834937008829772547\",\"id\":\"1834937008829772547_8322540155\",\"code\":\"Bl3AXzUhDMD\"}'),(4,'published',1,'timeline','Contrução de Casas e Terrenos! \nwww.nrvconstrutora.com.br','','{\"label\":\"Araraquara\",\"object\":\"C:36:\\\"InstagramAPI\\\\Response\\\\Model\\\\Location\\\":309:{a:7:{s:3:\\\"lat\\\";d:-21.79469999999999885176293901167809963226318359375;s:3:\\\"lng\\\";d:-48.17609999999999814690454513765871524810791015625;s:7:\\\"address\\\";s:10:\\\"Araraquara\\\";s:11:\\\"external_id\\\";s:15:\\\"108259652527599\\\";s:18:\\\"external_id_source\\\";s:15:\\\"facebook_places\\\";s:4:\\\"name\\\";s:10:\\\"Araraquara\\\";s:11:\\\"minimum_age\\\";i:0;}}\"}','5','0',5,0,'2018-08-07 14:19:54','2018-08-07 14:19:54','2018-08-07 14:20:01',0,'{\"upload_id\":\"137995047532023\",\"pk\":\"1840725471806217595\",\"id\":\"1840725471806217595_8322540155\",\"code\":\"BmLkhBkBd17\"}'),(5,'published',1,'timeline','Contrução de Casas e Terrenos! \nwww.nrvconstrutora.com.br','','{\"label\":\"Araraquara Morada do Sol\",\"object\":\"C:36:\\\"InstagramAPI\\\\Response\\\\Model\\\\Location\\\":336:{a:7:{s:3:\\\"lat\\\";d:-21.793972364571001065769451088272035121917724609375;s:3:\\\"lng\\\";d:-48.17938327789300245740378159098327159881591796875;s:7:\\\"address\\\";s:22:\\\"S\\u00e3o Paulo, Araraquara\\\";s:11:\\\"external_id\\\";s:15:\\\"821338214672792\\\";s:18:\\\"external_id_source\\\";s:15:\\\"facebook_places\\\";s:4:\\\"name\\\";s:24:\\\"Araraquara Morada do Sol\\\";s:11:\\\"minimum_age\\\";i:0;}}\"}','6','0',5,0,'2018-08-07 14:21:27','2018-08-07 14:21:27','2018-08-07 14:21:34',0,'{\"upload_id\":\"138087517114235\",\"pk\":\"1840726251024041237\",\"id\":\"1840726251024041237_8322540155\",\"code\":\"BmLksXRBkUV\"}'),(7,'published',1,'timeline','FINANCIAMENTO - TERRENOS E CONSTRUÇÃO.\nVenha conhecer a NRV Construtora!!! :tada::tada:\nCASAS À PARTIR DE R$125.000,00\n\n:arrow_right:Utilize seu FGTS.\n:arrow_right:Subsídios até R$ 20.000,00.\n:arrow_right:PARCELAMOS SUA ENTRADA.\n:arrow_right:Casas á partir de R$ 125.000,00.\n\nEntre em contato conosco e faça uma simulação! \nConstruímos no bairro de sua preferência!!\n\nContato: (16)99712-9129 / (16) 3508-7282\nwww.nrvconstrutora.com.br','','','9','0',5,0,'2018-08-08 10:36:00','2018-08-08 10:36:00','2018-08-08 10:36:06',0,'{\"upload_id\":\"210960906621456\",\"pk\":\"1841337557158642068\",\"id\":\"1841337557158642068_8322540155\",\"code\":\"BmNvsCeBsGU\"}'),(8,'published',1,'timeline','FINANCIAMENTO - TERRENOS E CONSTRUÇÃO.\nVenha conhecer a NRV Construtora!!! :tada::tada:\nCASAS À PARTIR DE R$125.000,00\n\n:arrow_right:Utilize seu FGTS.\n:arrow_right:Subsídios até R$ 20.000,00.\n:arrow_right:PARCELAMOS SUA ENTRADA.\n:arrow_right:Casas á partir de R$ 125.000,00.\n\nEntre em contato conosco e faça uma simulação! \nConstruímos no bairro de sua preferência!!\n\nContato: (16)99712-9129 / (16) 3508-7282\nwww.nrvconstrutora.com.br','','','10','0',5,0,'2018-08-08 10:37:20','2018-08-08 10:37:20','2018-08-08 10:37:25',0,'{\"upload_id\":\"211040248198650\",\"pk\":\"1841338217627243297\",\"id\":\"1841338217627243297_8322540155\",\"code\":\"BmNv1plBdMh\"}'),(9,'published',1,'timeline','FINANCIAMENTO - TERRENOS E CONSTRUÇÃO.\nVenha conhecer a NRV Construtora!!! :tada::tada:\nCASAS À PARTIR DE R$125.000,00\n\n:arrow_right:Utilize seu FGTS.\n:arrow_right:Subsídios até R$ 20.000,00.\n:arrow_right:PARCELAMOS SUA ENTRADA.\n:arrow_right:Casas á partir de R$ 125.000,00.\n\nEntre em contato conosco e faça uma simulação! \nConstruímos no bairro de sua preferência!!\n\nContato: (16)99712-9129 / (16) 3508-7282\nwww.nrvconstrutora.com.br','','','11','0',5,0,'2018-08-08 10:38:26','2018-08-08 10:38:26','2018-08-08 10:38:32',0,'{\"upload_id\":\"211106553576006\",\"pk\":\"1841338778355393028\",\"id\":\"1841338778355393028_8322540155\",\"code\":\"BmNv9zzBmIE\"}'),(10,'published',1,'timeline','FINANCIAMENTO - TERRENOS E CONSTRUÇÃO.\nVenha conhecer a NRV Construtora!!! :tada::tada:\nCASAS À PARTIR DE R$125.000,00\n\n:arrow_right:Utilize seu FGTS.\n:arrow_right:Subsídios até R$ 20.000,00.\n:arrow_right:PARCELAMOS SUA ENTRADA.\n:arrow_right:Casas á partir de R$ 125.000,00.\n\nEntre em contato conosco e faça uma simulação! \nConstruímos no bairro de sua preferência!!\n\nContato: (16)99712-9129 / (16) 3508-7282\nwww.nrvconstrutora.com.br','','','12','0',5,0,'2018-08-08 10:38:51','2018-08-08 10:38:51','2018-08-08 10:38:56',0,'{\"upload_id\":\"211131185757893\",\"pk\":\"1841338981435276651\",\"id\":\"1841338981435276651_8322540155\",\"code\":\"BmNwAw7h31r\"}'),(11,'published',11,'timeline','','','','13','0',7,0,'2018-08-08 16:44:21','2018-08-08 16:44:21','2018-08-08 16:44:25',0,'{\"upload_id\":\"233062298334959\",\"pk\":\"1841522945529335668\",\"id\":\"1841522945529335668_8395304569\",\"code\":\"BmOZ1y2Ac90\"}'),(15,'scheduled',17,'timeline','test','','','15','0',10,1,'2018-08-09 02:00:44','2018-08-09 02:05:00','2018-08-09 02:00:44',0,'{}'),(16,'published',19,'timeline','test','','','16','0',11,0,'2018-08-09 11:14:32','2018-08-09 11:14:32','2018-08-09 11:14:37',0,'{\"upload_id\":\"299672796557921\",\"pk\":\"1842081717192532913\",\"id\":\"1842081717192532913_8398536231\",\"code\":\"BmQY4_ggKOx\"}'),(17,'scheduled',17,'timeline','test','','','15','0',13,1,'2018-08-09 11:18:37','2018-08-09 11:25:00','2018-08-09 11:18:37',0,'{}'),(18,'published',1,'timeline',':rotating_light:ESSA É A HORA DE TER SUA CASA PRÓPRIA E SAIR DO ALUGUEL!!!:rotating_light:\n\n:heavy_check_mark:Casas á partir de R$ 125.000,00 do seu jeito em 5 meses!!:house_with_garden:\n\n:heavy_check_mark:Pelo programa MINHA CASA MINHA VIDA do governo Ferderal\n\n:heavy_check_mark:Subsídios até R$ 20.000,00\n\n:heavy_check_mark:PARCELAMOS SUA ENTRADA\n\n:heavy_check_mark:Use seu FGTS como forma de pagamento\n\nVenha conferir nossas condições , você vai se surpreender!!!:open_mouth:\nEntre em contato e agende uma visita (16)98100-7979/ 3508-7282 - www.nrvconstrutora.com.br','','','17','0',5,0,'2018-08-09 13:00:29','2018-08-09 13:00:29','2018-08-09 13:00:36',0,'{\"upload_id\":\"306029799560886\",\"pk\":\"1842135052356927108\",\"id\":\"1842135052356927108_8322540155\",\"code\":\"BmQlBHwB76E\"}'),(19,'published',1,'timeline','Temos variedades em \nEspetos De:\n-Panceta suína \n- Alcatra bovina\n- Filé mignom bovino\n- Coração de frango \n- Kafta bovina\n- Kafta suína\n- Kafta de frango\n- Medalhão de frango\n- Medalhão de Mandioca \n- Queijo de coalho\n- Queijo bola defumado\n- Queijo bola branca\n- Linguiça de pernil fina\n- Pão de alho\n\n**Todos os espetos são temperdos prontos para assar.\nSó aqui na casa de Carnes Central! :heart_eyes::heart_eyes: \nEncomende o seu - Tel.(16)3301-4955\nRua: 9 de Julho, 318 - Centro - Araraquara-SP','','','19','0',16,0,'2018-08-09 23:44:59','2018-08-09 23:44:59','2018-08-09 23:45:08',0,'{\"upload_id\":\"344700032530158\",\"pk\":\"1842459474665711556\",\"id\":\"1842459474665711556_8403607912\",\"code\":\"BmRuyFkgKfE\"}'),(20,'published',1,'timeline','PROMOÇÃO ESPECIAL!:heart:\nMaminha Especial = R$19,85:point_left:\n:arrow_right:Faça sua encomenda - Tel.(16)3301-4955\nRua: 9 de Julho, 318 - Centro - Araraquara-SP','','','20','0',16,0,'2018-08-09 23:45:38','2018-08-09 23:45:38','2018-08-09 23:45:45',0,'{\"upload_id\":\"344740385050880\",\"pk\":\"1842459771110831503\",\"id\":\"1842459771110831503_8403607912\",\"code\":\"BmRu2ZqAjWP\"}'),(21,'published',1,'timeline','As Melhores PRIMES\nRaças Britânicas \n- Prime Rib Steak\n- Bife Capitão\n- Assado de Tira Premium\n- T-Bone Steak\n- Prime Rib Tomahawk\n- Shoulder Steak\n- Bife de Chorizo\n- Carré de Cordeiro \n- Bife de Ancho\n- Carré de Cordeiro \nEncomende o seu - Tel.(16)3301-4955\nRua: 9 de Julho, 318 - Centro - Araraquara-SP\n#araraquara #moradadosol','','','21','0',16,0,'2018-08-09 23:46:29','2018-08-09 23:46:29','2018-08-09 23:46:34',0,'{\"upload_id\":\"344790086304247\",\"pk\":\"1842460188653814152\",\"id\":\"1842460188653814152_8403607912\",\"code\":\"BmRu8ehgoGI\"}'),(22,'published',1,'timeline','SHOW DE OFERTAS DE CARNE SUÍNA!\nFILÉ MIGNON SUÍNO - Apenas R$14,90Kg:point_left:\n:arrow_right:Faça sua encomenda - Tel.(16)3301-4955\nRua: 9 de Julho, 318 - Centro - Araraquara-SP','','','22','0',16,0,'2018-08-09 23:47:06','2018-08-09 23:47:06','2018-08-09 23:47:11',0,'{\"upload_id\":\"344827223012451\",\"pk\":\"1842460498512295790\",\"id\":\"1842460498512295790_8403607912\",\"code\":\"BmRvA_Gg7du\"}'),(23,'published',1,'timeline','O Dia do Pais merece algo Especial!:tada::yum::tada::yum:\nPara Nosso Capitão, um Bife Capitão:heart::heart:\ncom Super Desconto, apenas: R$24,90\n:arrow_right:Tel.(16) 3301-4955\nEndereço: Rua Nove de Julho 318:checkered_flag:','','','23','0',16,0,'2018-08-09 23:48:23','2018-08-09 23:48:23','2018-08-09 23:48:28',0,'{\"upload_id\":\"344903579885258\",\"pk\":\"1842461138093103134\",\"id\":\"1842461138093103134_8403607912\",\"code\":\"BmRvKSwgFge\"}'),(24,'published',1,'timeline','S O R T E I O - D I A D O S P A I S\nCURTA, COMPARTILHE E MARQUE 03 AMIGOS\nCONCORRA À UM Belíssimo KIT CHURRASCO para seu PAIZÃO.\n\n1 PEÇA DE PICANHA NOBRE GRILL\n1KG CARRÉ FRANCÊS DE CORDEIRO\n1 KG DE LINGUIÇA CUIABANA DE ALCATRA C/ QUEIJO\n1 KG TULIPA DE FRANGO TEMPERADA\n1 PACOTE DE QUEIJO COALHO QUATÁ\n1 BANDEJA DE PÃO DE ALHO HIPER\n1 CARVÃO\n1 CX SKOL LATA\n1 COCA 2 LITROS.\n\n:arrow_right:Sorteio dia 11.08.2018\nLigue para agendar a retirada: \n(16) 3301-4955:checkered_flag:\nEndereço: Rua Nove de Julho 318','','','24','0',16,0,'2018-08-09 23:49:10','2018-08-09 23:49:10','2018-08-09 23:49:16',0,'{\"upload_id\":\"344951055190157\",\"pk\":\"1842461540922484797\",\"id\":\"1842461540922484797_8403607912\",\"code\":\"BmRvQJ7AOg9\"}'),(25,'published',1,'timeline','Se você busca acabamento perfeitos, a Manini marmoraria é a empresa certa para te atender! \nCotações:point_down:\n:arrow_right:Fone: (16) 3336-5290\nE-Mail: manini@maninimarmoraria.com.br\nwww.maninimarmoraria.com.br:checkered_flag:','','','25','0',17,0,'2018-08-10 00:22:45','2018-08-10 00:22:45','2018-08-10 00:22:50',0,'{\"upload_id\":\"346966192187389\",\"pk\":\"1842478442115062487\",\"id\":\"1842478442115062487_8403138748\",\"code\":\"BmRzGGYlVrX\"}'),(26,'published',1,'timeline','Cozinhas com Design moderno! Agende conosco um orçamento!\n:arrow_right:Fone: (16) 3336-5290\nE-Mail: manini@maninimarmoraria.com.br\nwww.maninimarmoraria.com.br','','','26','0',17,0,'2018-08-10 00:23:18','2018-08-10 00:23:18','2018-08-10 00:23:23',0,'{\"upload_id\":\"346998952085849\",\"pk\":\"1842478717387310152\",\"id\":\"1842478717387310152_8403138748\",\"code\":\"BmRzKGwFoRI\"}'),(27,'published',1,'timeline','A COZINHA QUE VOCÊ SONHOU!\nCotações:point_down:\nFone: (16) 3336-5290\nE-Mail: manini@maninimarmoraria.com.br','','','27','0',17,0,'2018-08-10 00:24:06','2018-08-10 00:24:06','2018-08-10 00:24:11',0,'{\"upload_id\":\"347047924236699\",\"pk\":\"1842479127766323647\",\"id\":\"1842479127766323647_8403138748\",\"code\":\"BmRzQE8lVG_\"}'),(28,'published',1,'timeline','O Banheiro dos seus sonhos!\nCotações:point_down:\nFone: (16) 3336-5290\nE-Mail: manini@maninimarmoraria.com.br','','','28','0',17,0,'2018-08-10 00:27:14','2018-08-10 00:27:14','2018-08-10 00:27:18',0,'{\"upload_id\":\"347235372205861\",\"pk\":\"1842480700722536954\",\"id\":\"1842480700722536954_8403138748\",\"code\":\"BmRzm94FGH6\"}'),(29,'published',1,'timeline','FINANCIAMENTO - TERRENOS E CONSTRUÇÃO.\nVenha conhecer a NRV Construtora!!! :tada::tada:\nCASAS À PARTIR DE R$125.000,00\n\n:arrow_right:Utilize seu FGTS.\n:arrow_right:Subsídios até R$ 20.000,00.\n:arrow_right:PARCELAMOS SUA ENTRADA.\n:arrow_right:Casas á partir de R$ 125.000,00.\n\nEntre em contato conosco e faça uma simulação! \nConstruímos no bairro de sua preferência!!\n\nContato: (16)99712-9129 / (16) 3508-7282\nwww.nrvconstrutora.com.br','','','29','0',5,0,'2018-08-10 12:15:56','2018-08-10 12:15:56','2018-08-10 12:16:02',0,'{\"upload_id\":\"389756206346879\",\"pk\":\"1842837401807254383\",\"id\":\"1842837401807254383_8322540155\",\"code\":\"BmTEtpphnNv\"}');
/*!40000 ALTER TABLE `np_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_proxies`
--

DROP TABLE IF EXISTS `np_proxies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_proxies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proxy` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_code` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `use_count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_proxies`
--

LOCK TABLES `np_proxies` WRITE;
/*!40000 ALTER TABLE `np_proxies` DISABLE KEYS */;
INSERT INTO `np_proxies` VALUES (1,'http://181.214.6.47:3128','BR',2),(2,'http://181.214.20.37:3128','BR',3),(3,'http://181.214.26.18:3128','BR',2),(5,'http://191.96.137.156:3128','BR',3),(6,'http://191.96.11.182:3128','BR',0);
/*!40000 ALTER TABLE `np_proxies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_users`
--

DROP TABLE IF EXISTS `np_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `package_id` int(11) NOT NULL,
  `package_subscription` tinyint(1) NOT NULL,
  `settings` text COLLATE utf8_unicode_ci NOT NULL,
  `preferences` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` int(11) NOT NULL,
  `expire_date` datetime NOT NULL,
  `date` datetime NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_users`
--

LOCK TABLES `np_users` WRITE;
/*!40000 ALTER TABLE `np_users` DISABLE KEYS */;
INSERT INTO `np_users` VALUES (1,'admin','contato@connectwebmarketing.com.br','admin','$2y$10$0GHysgSAybkZbHUt4.Fk6.jSRHk1oHXgpFL2kStIDPV8p0ivlhTfG','Connect','Web Marketing',3,1,'{\"storage\":{\"total\":\"300.00\",\"file\":\"50.00\"},\"max_accounts\":50,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\",\"language\":\"pt-BR\"}',1,'2030-12-31 23:59:59','2018-07-24 23:05:24','{}'),(2,'member','toledo.connect@gmail.com','user_5b57d52773a4a','$2y$10$3Q9gqtw7bsIekvDUlb6gXeUUJviE7KWeAT7mHDuBa/Os8RXISNZsi','vergilio','toledo',2,0,'{\"storage\":{\"total\":\"250.00\",\"file\":\"30.00\"},\"max_accounts\":3,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\",\"language\":\"pt-BR\"}',1,'2019-03-01 01:39:00','2018-07-25 01:40:55','{}'),(3,'member','matheus.esilva@gmail.com','user_5b5879e8b18ef','$2y$10$XDlIL/rfA8SvLJ8rA/sf/uoMMSDEis0OfNM6txyWtaUpZbssdDzgO','Matheus','Silva',2,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":1,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"d-m-Y\",\"timeformat\":\"24\",\"language\":\"pt-BR\"}',1,'2018-08-01 13:23:00','2018-07-25 13:23:52','{}'),(4,'member','viniciusguellis@gmail.com','user_5b5f67c38e104','$2y$10$dXzMEOmh1m4KsUBRyezjcOhzZE7XDh7HOiamECHo5urKLRgCc8ZsK','Vinicius','Guellis',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":1,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-08-06 19:32:19','2018-07-30 19:32:19','{}'),(6,'member','danilopz@gmail.com','user_5b69794ca8a81','$2y$10$fnnV.On6NaZnAD3Tlxr1oOj3o6tv59k1sUWEAHg2NBCOkXNJHSRkC','Danilo','Perez',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-06 10:49:48','2018-08-07 10:49:48','{}'),(7,'member','test@testing.com','user_5b697e8b4b3e9','$2y$10$i9p.m0tBHcIJpgMeDgFoVuPoBdh7lyDj3283E2AXtK8IJ5DYVDFbW','Test','Test',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"Asia\\/Karachi\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-06 11:12:11','2018-08-07 11:12:11','{}'),(8,'member','sitecasadainfo2011@gmail.com','user_5b69a497482ed','$2y$10$KJ3VgQqb2ckpNLl5q9OoCOEzBC25Zyq75kd3ej88erH7cVq7NyAZC','Giovani','Junior',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-06 13:54:31','2018-08-07 13:54:31','{}'),(9,'member','felipe@4steps.com.br','user_5b69b039313bf','$2y$10$PvkHSOFcMIQ1LyvL/DPuHOgAHiNI0K29n1SDDtF9e54rJ/zz5duum','Felipe','Ladislau',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Belem\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-06 14:44:09','2018-08-07 14:44:09','{}'),(10,'member','marcelo@w2n.com.br','user_5b69d7d0bd85d','$2y$10$2ibkI3bSEE/qQMGeLzQyJu3/t7E9FMhH6yllrYsv1xerl7I8giQv6','Marcelo','Santos',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-06 17:33:04','2018-08-07 17:33:04','{}'),(11,'member','taymisondeveloper@gmail.com','user_5b6b19b29ca46','$2y$10$Gm7S/bCU.ctpU9N6dMkQwO0kpu6jV06w//3xttAu79Mv1aDvFQ3Be','Taymison','Ramos',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-07 16:26:26','2018-08-08 16:26:26','{}'),(12,'member','syan_cs22@hotmail.com','user_5b6b408314990','$2y$10$rBm.gg8042yGIC0W2/jb3usXgMDxOIRuXM7gcOzYQU1iNm82SAWau','Syan','Souza',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\",\"language\":\"en-US\"}',1,'2018-09-07 19:12:03','2018-08-08 19:12:03','{}'),(13,'member','bugecev@zippiex.com','user_5b6b47bfc1d51','$2y$10$X/Di3jFnSeZU.9PjJaDj0OKODitK393CKCy.Izg2setYRp5EFritK','Luiz','Felipe',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-07 19:42:55','2018-08-08 19:42:55','{}'),(14,'member','teste@teste.com.br','user_5b6b5b59183f5','$2y$10$bkg2IK2Hqhvp.eoofxh3NuqxBiqIh9t3c1IWqPQNIGi9ckN/TSO9e','Teste','Teste',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-07 21:06:33','2018-08-08 21:06:33','{}'),(15,'member','samsonogen@gmail.com','user_5b6b87d348448','$2y$10$5I.RtqmJ3GH7kIS2F1mci.YZeWXgFfYhubZqv0f.oq.IsgiZp9W/u','samson','dadson',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"Africa\\/Accra\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-08 00:16:19','2018-08-09 00:16:19','{}'),(16,'member','matheusdiogenesandrade@gmail.com','user_5b6b920ec1fea','$2y$10$7jCLHLXMeYe0Y4Qe6G25HOUR8QVPX2tvHIixTesJ1SxBcn4au60my','Matheus Diógenes','Andrade',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-08 00:59:58','2018-08-09 00:59:58','{}'),(17,'member','diegophh@gmail.com','user_5b6b9497d84c0','$2y$10$Mpw6pCHljVFBoINzMaSuBee63T9sSEQiPdedPQAdt0/dhiFmLde/q','Diego','Schmidt',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-08 01:10:47','2018-08-09 01:10:47','{}'),(18,'member','shahidbasheer5551@gmail.com','user_5b6c1e5558546','$2y$10$BLPaycMxzNRTVu3bfIzXheyVlGzbcIOXmH4ppRAVd9TqB5tVDsNBy','shahid','bashir',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"Asia\\/Karachi\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-08 10:58:29','2018-08-09 10:58:29','{}'),(19,'member','thisisdemo1234@gmail.com','user_5b6c1e858b2b2','$2y$10$ilLGGZccbeKjpaYLe.hMpOwBeaF5aR44eWjlkZzOkMN8COqa3Tw8m','test','test',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"Asia\\/Kolkata\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-08 10:59:17','2018-08-09 10:59:17','{}'),(20,'member','deljdl@gmail.com','user_5b6c2500f27de','$2y$10$k9yteG7q0yvnGvalFStV7OfVWOdT/xKd5PO4RHX3gAEAK47b0XmXW','Jardel','Jacomini',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"America\\/Sao_Paulo\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\"}',1,'2018-09-08 11:26:56','2018-08-09 11:26:56','{}'),(21,'member','sonia13145@gmail.com','user_5b6ca5b6338b0','$2y$10$csRqGBwH22isTr.drLET5OqSGz5bQPT13Mjjn5XEnkoPAGWwG/cy2','sonia','ge',0,0,'{\"storage\":{\"total\":\"100.00\",\"file\":-1},\"max_accounts\":5,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"Asia\\/Karachi\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\",\"language\":\"en-US\"}',1,'2018-09-08 20:36:00','2018-08-09 20:36:06','{}'),(22,'member','saulohbrancalion@gmail.com','user_5b6d924869721','$2y$10$GJFq3vN2Lby7TH1Ur0ZjH.xoxWUuxrKp9j0vc2YL2q7JyQ/Lpq/LG','Saulo','Bra',0,0,'{\"storage\":{\"total\":\"120.00\",\"file\":\"10.00\"},\"max_accounts\":1,\"file_pickers\":{\"dropbox\":true,\"onedrive\":true,\"google_drive\":true},\"post_types\":{\"timeline_photo\":true,\"timeline_video\":true,\"story_photo\":true,\"story_video\":true,\"album_photo\":true,\"album_video\":true},\"spintax\":true,\"modules\":[\"auto-comment\",\"auto-follow\",\"auto-like\",\"auto-repost\",\"auto-unfollow\",\"welcomedm\"]}','{\"timezone\":\"Pacific\\/Midway\",\"dateformat\":\"Y-m-d\",\"timeformat\":\"24\",\"language\":\"en-US\"}',1,'2018-09-09 13:24:00','2018-08-10 13:25:28','{}');
/*!40000 ALTER TABLE `np_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_welcomedm_log`
--

DROP TABLE IF EXISTS `np_welcomedm_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_welcomedm_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `follower_id` varchar(50) NOT NULL,
  `data` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  KEY `follower_id` (`follower_id`),
  CONSTRAINT `ibfk_5b68fe9f78ed8` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b68fe9f78ed9` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_welcomedm_log`
--

LOCK TABLES `np_welcomedm_log` WRITE;
/*!40000 ALTER TABLE `np_welcomedm_log` DISABLE KEYS */;
INSERT INTO `np_welcomedm_log` VALUES (1,2,3,'success','6174750156','{\"message\":\"@bereadysaude\\nSomos a NRV Construtora. \\nEspecializados em constru\\u00e7\\u00e3o de casas.\\n\\nFINANCIE CONOSCO O TERRENO E A CONSTRU\\u00c7\\u00c3O. \\nOBRAS A PARTIR DE R$125.000,000\\n\\nwww.nrvconstruora.com.br\",\"to\":{\"id\":\"6174750156\",\"username\":\"bereadysaude\",\"fullname\":null,\"profile_pic\":\"https:\\/\\/scontent-gru2-1.cdninstagram.com\\/vp\\/88172f753cee86f9652c178225b892a1\\/5C1122E7\\/t51.2885-19\\/s150x150\\/22220516_507462636283606_8451875548329672704_n.jpg\"}}','2018-08-07 23:39:03'),(2,1,5,'success','6174750156','{\"message\":\"@bereadysaude\\nObrigado!!\\nConhe\\u00e7a mais sobre nossa empresa!\\nwww.nrvconstrutora.com.br\",\"to\":{\"id\":\"6174750156\",\"username\":\"bereadysaude\",\"fullname\":null,\"profile_pic\":\"https:\\/\\/scontent-gru2-1.cdninstagram.com\\/vp\\/88172f753cee86f9652c178225b892a1\\/5C1122E7\\/t51.2885-19\\/s150x150\\/22220516_507462636283606_8451875548329672704_n.jpg\"}}','2018-08-07 23:39:06');
/*!40000 ALTER TABLE `np_welcomedm_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `np_welcomedm_schedule`
--

DROP TABLE IF EXISTS `np_welcomedm_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_welcomedm_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `messages` text NOT NULL,
  `speed` varchar(20) NOT NULL,
  `daily_pause` tinyint(1) NOT NULL,
  `daily_pause_from` time NOT NULL,
  `daily_pause_to` time NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `schedule_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `last_action_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `ibfk_5b68fe9f78ed4` FOREIGN KEY (`user_id`) REFERENCES `np_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ibfk_5b68fe9f78ed7` FOREIGN KEY (`account_id`) REFERENCES `np_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_welcomedm_schedule`
--

LOCK TABLES `np_welcomedm_schedule` WRITE;
/*!40000 ALTER TABLE `np_welcomedm_schedule` DISABLE KEYS */;
INSERT INTO `np_welcomedm_schedule` VALUES (1,2,3,'[\"{{username}}\\nSomos a NRV Construtora. \\nEspecializados em constru\\u00e7\\u00e3o de casas.\\n\\nFINANCIE CONOSCO O TERRENO E A CONSTRU\\u00c7\\u00c3O. \\nOBRAS A PARTIR DE R$125.000,000\\n\\nwww.nrvconstruora.com.br\"]','0',0,'00:00:00','00:00:00',1,'2018-08-08 00:27:16','2030-12-12 23:59:59','2018-08-07 23:39:01'),(2,1,5,'[\"{{username}}\\nObrigado!!\\nConhe\\u00e7a mais sobre nossa empresa!\\nwww.nrvconstrutora.com.br\"]','5',0,'00:00:00','00:00:00',1,'2018-08-08 01:15:31','2030-12-12 23:59:59','2018-08-07 23:39:05'),(3,1,16,'[\"{{username}} Obrigado por nos seguir.\\nConvidamos voc\\u00ea a fazer uma visita em nossa loja.\"]','5',0,'00:00:00','00:00:00',1,'2018-08-09 23:53:44','2030-12-12 23:59:59','2018-08-09 23:50:29'),(4,1,17,'[\"{{username}} Obrigado por seguir a Marmoraria Manini!\\nVenha conhecer:\\nhttps:\\/\\/www.maninimarmoraria.com.br\"]','5',0,'00:00:00','00:00:00',1,'2018-08-10 00:29:36','2030-12-12 23:59:59','2018-08-10 00:28:36');
/*!40000 ALTER TABLE `np_welcomedm_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'gerenciainsta'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-16 10:24:45
